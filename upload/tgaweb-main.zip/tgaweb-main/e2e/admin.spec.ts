import { test, expect } from '@playwright/test';

/**
 * Admin panel E2E tests.
 *
 * Tests cover:
 *   - Login flow (correct + incorrect credentials)
 *   - Admin dashboard loads
 *   - Content CRUD (create news article, verify on public site, delete)
 *   - 2FA enforcement (if enabled)
 *
 * Test credentials (from scripts/seed.ts):
 *   Email:    admin@trailgliders.edu.ng
 *   Password: TrailGliders2026!
 *
 * These tests mutate the database (create + delete a news article).
 * They run against the fresh seeded DB in CI, so cleanup isn't strictly
 * required — but we still try to clean up in case tests run against a
 * persistent staging DB.
 */

const ADMIN_EMAIL = process.env.ADMIN_EMAIL || 'admin@trailgliders.edu.ng';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'TrailGliders2026!';

test.describe('Admin authentication', () => {
  test('login page loads', async ({ page }) => {
    await page.goto('/admin/login');
    await expect(page).toHaveTitle(/login|admin|Trail Gliders/i);
    await expect(page.locator('input[type="email"]').first()).toBeVisible();
    await expect(page.locator('input[type="password"]').first()).toBeVisible();
  });

  test('incorrect credentials show error', async ({ page }) => {
    await page.goto('/admin/login');

    await page.locator('input[type="email"]').first().fill('wrong@example.com');
    await page.locator('input[type="password"]').first().fill('wrongpassword');
    await page.locator('button[type="submit"]').first().click();

    // Should show an error message, NOT redirect to dashboard
    await page.waitForTimeout(2000);
    expect(page.url()).toContain('/admin/login');
  });

  test('correct credentials log in successfully', async ({ page }) => {
    await page.goto('/admin/login');

    await page.locator('input[type="email"]').first().fill(ADMIN_EMAIL);
    await page.locator('input[type="password"]').first().fill(ADMIN_PASSWORD);
    await page.locator('button[type="submit"]').first().click();

    // Should redirect away from /login (to /admin/dashboard or /admin/2fa-verify)
    await page.waitForURL(url => !url.toString().includes('/admin/login'), { timeout: 15000 });
    expect(page.url()).not.toContain('/admin/login');
  });
});

// For tests that need to be logged in, log in once and reuse the session
test.describe('Admin panel (authenticated)', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/admin/login');
    await page.locator('input[type="email"]').first().fill(ADMIN_EMAIL);
    await page.locator('input[type="password"]').first().fill(ADMIN_PASSWORD);
    await page.locator('button[type="submit"]').first().click();
    // Wait for redirect away from login
    await page.waitForURL(url => !url.toString().includes('/admin/login'), { timeout: 15000 });
  });

  test('dashboard loads with quick actions', async ({ page }) => {
    await page.goto('/admin/dashboard');
    await expect(page).toHaveTitle(/dashboard|admin|Trail Gliders/i);

    // Dashboard should have some kind of navigation or stats
    const main = page.locator('main').first();
    await expect(main).toBeVisible();
  });

  test('settings page loads', async ({ page }) => {
    await page.goto('/admin/settings');
    await expect(page.locator('main').first()).toBeVisible();
    // Should show the school name input
    await expect(page.locator('input, textarea').first()).toBeVisible({ timeout: 10000 });
  });

  test('news admin page loads with article list', async ({ page }) => {
    await page.goto('/admin/news');
    await expect(page.locator('main').first()).toBeVisible();
    // Should have an "Add News Item" button
    await expect(page.locator('text=/Add News/i').first()).toBeVisible({ timeout: 10000 });
  });

  test('programs admin page loads', async ({ page }) => {
    await page.goto('/admin/programs');
    await expect(page.locator('main').first()).toBeVisible();
    await expect(page.locator('text=/Add Program/i').first()).toBeVisible({ timeout: 10000 });
  });

  test('faculty admin page loads', async ({ page }) => {
    await page.goto('/admin/faculty');
    await expect(page.locator('main').first()).toBeVisible();
    await expect(page.locator('text=/Add Faculty/i').first()).toBeVisible({ timeout: 10000 });
  });

  test('users admin page loads (admin-only)', async ({ page }) => {
    await page.goto('/admin/users');
    await expect(page.locator('main').first()).toBeVisible({ timeout: 10000 });
  });
});

test.describe('News article CRUD', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/admin/login');
    await page.locator('input[type="email"]').first().fill(ADMIN_EMAIL);
    await page.locator('input[type="password"]').first().fill(ADMIN_PASSWORD);
    await page.locator('button[type="submit"]').first().click();
    await page.waitForURL(url => !url.toString().includes('/admin/login'), { timeout: 15000 });
  });

  test('create a news article, verify on public site, delete it', async ({ page }) => {
    const timestamp = Date.now();
    const title = `E2E Test Article ${timestamp}`;
    const excerpt = `This is a test excerpt created by Playwright at ${new Date().toISOString()}`;

    // ── Create ─────────────────────────────────────────────────────────
    await page.goto('/admin/news');
    await page.locator('text=/Add News/i').first().click();

    // Wait for the edit dialog to open
    await expect(page.locator('[role="dialog"]').first()).toBeVisible({ timeout: 5000 });

    // Fill in required fields
    await page.locator('input[name="title"], #title').first().fill(title);
    await page.locator('input[name="date"], input[type="date"]').first().fill(new Date().toISOString().split('T')[0]);
    await page.locator('input[name="tag"], #tag').first().fill('E2E');
    await page.locator('input[name="image"], #image').first().fill('/images/news/test.jpg');
    await page.locator('textarea[name="excerpt"], #excerpt').first().fill(excerpt);

    // Save
    await page.locator('button[type="submit"], text=/Save Changes/i').last().click();

    // Wait for dialog to close
    await expect(page.locator('[role="dialog"]')).toBeHidden({ timeout: 10000 });

    // ── Verify on public site ──────────────────────────────────────────
    await page.goto('/en/news');
    // The new article should appear in the list
    await expect(page.locator(`text=${title}`).first()).toBeVisible({ timeout: 15000 });

    // ── Delete (cleanup) ───────────────────────────────────────────────
    await page.goto('/admin/news');

    // Find the article in the admin list and click its delete button
    const articleCard = page.locator(`[class*="rounded"]:has-text("${title}")`).first();
    await expect(articleCard).toBeVisible({ timeout: 10000 });

    // Click the delete/trash icon within that card
    const deleteButton = articleCard.locator('button:has(svg), [aria-label*="delete" i], button:has-text("Delete")').first();
    await deleteButton.click();

    // Confirm in the dialog
    const confirmButton = page.locator('[role="alertdialog"] button:has-text("Delete"), [role="dialog"] button:has-text("Delete")').last();
    await expect(confirmButton).toBeVisible({ timeout: 5000 });
    await confirmButton.click();

    // Wait for the dialog to close and the article to disappear
    await page.waitForTimeout(2000);
    await expect(page.locator(`text=${title}`)).toBeHidden({ timeout: 10000 });
  });
});

test.describe('Admin security', () => {
  test('admin pages redirect to login when not authenticated', async ({ page, context }) => {
    // Clear all cookies to ensure we're logged out
    await context.clearCookies();

    await page.goto('/admin/dashboard');
    // Should redirect to /admin/login
    await page.waitForURL(url => url.toString().includes('/admin/login'), { timeout: 10000 });
    expect(page.url()).toContain('/admin/login');
  });

  test('admin API returns 401 when not authenticated', async ({ request }) => {
    const endpoints = [
      '/api/admin/me',
      '/api/admin/settings',
      '/api/admin/news',
      '/api/admin/programs',
      '/api/admin/faculty',
    ];

    for (const url of endpoints) {
      const response = await request.get(url);
      expect(response.status(), `${url} should return 401`).toBe(401);
    }
  });
});
