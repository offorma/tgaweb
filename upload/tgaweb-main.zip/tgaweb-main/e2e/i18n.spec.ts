import { test, expect } from '@playwright/test';

/**
 * Internationalization (i18n) E2E tests.
 *
 * Verifies:
 *   - Locale-prefixed URLs work (/en/, /fr/, /ha/, /ig/, /yo/)
 *   - Root URL redirects to default locale (/en/)
 *   - Language switcher changes the URL prefix
 *   - UI chrome (navbar, footer) translates per locale
 *   - Content fallback works (missing translation shows English)
 *   - hreflang alternate links are present in <head>
 */

const LOCALES = ['en', 'fr', 'ha', 'ig', 'yo'];

test.describe('Locale routing', () => {
  test('root URL redirects to default locale', async ({ page }) => {
    const response = await page.goto('/');
    // Should redirect to /en/ (defaultLocale)
    expect(page.url()).toMatch(/\/en\/?$/);
  });

  test('unknown locale falls back to default', async ({ page }) => {
    const response = await page.goto('/de/');
    // Should either redirect to /en/ or show 404 — both acceptable
    // The key is no 500 server error
    expect(response?.status()).toBeLessThan(500);
  });
});

test.describe('Language switcher', () => {
  test('clicking French in the switcher navigates to /fr/', async ({ page }) => {
    await page.goto('/en/');

    // Find the language switcher button (globe icon + chevron)
    const switcherButton = page.locator('button[aria-label*="language" i], button:has(svg.lucide-globe)').first();
    await expect(switcherButton).toBeVisible();
    await switcherButton.click();

    // Wait for dropdown to open
    const frenchOption = page.locator('button:has-text("Français"), button:has-text("fr")').first();
    await expect(frenchOption).toBeVisible({ timeout: 5000 });
    await frenchOption.click();

    // URL should now have /fr/ prefix
    await page.waitForURL(url => url.toString().includes('/fr/'), { timeout: 10000 });
    expect(page.url()).toContain('/fr/');
  });

  test('language switcher highlights current locale', async ({ page }) => {
    await page.goto('/ha/');

    const switcherButton = page.locator('button[aria-label*="language" i], button:has(svg.lucide-globe)').first();
    await switcherButton.click();

    // The Hausa option should have a "check" icon (active state)
    const hausaOption = page.locator('button:has-text("Hausa")').first();
    await expect(hausaOption).toBeVisible();
    // The active option typically has different styling (e.g., bg-orange/10)
    const classNames = await hausaOption.getAttribute('class');
    expect(classNames).toContain('orange');
  });
});

test.describe('UI chrome translation', () => {
  // Test that navbar items translate correctly
  // The exact text depends on messages/{locale}.json content
  test('English navbar shows "News"', async ({ page }) => {
    await page.goto('/en/');
    // Find the navbar and check it contains "News" link text
    const nav = page.locator('header nav, nav').first();
    await expect(nav).toBeVisible();
    const navText = await nav.textContent();
    expect(navText).toMatch(/News/i);
  });

  test('French navbar shows translated "News"', async ({ page }) => {
    await page.goto('/fr/');
    const nav = page.locator('header nav, nav').first();
    await expect(nav).toBeVisible();
    const navText = await nav.textContent();
    // The French translation of "News" — depends on messages/fr.json
    // If no translation exists, it falls back to "News"
    // Just verify SOMETHING is rendered (no empty navbar)
    expect(navText?.trim().length).toBeGreaterThan(0);
  });
});

test.describe('hreflang alternate links', () => {
  test('homepage has hreflang alternate links for all locales', async ({ page }) => {
    await page.goto('/en/');

    // Check <link rel="alternate" hreflang="..."> tags exist
    const alternates = page.locator('link[rel="alternate"]');
    const count = await alternates.count();

    // Should have at least 5 (one per locale) + possibly x-default
    expect(count).toBeGreaterThanOrEqual(5);

    // Verify each locale is present
    const hreflangs = await alternates.evaluateAll(els =>
      els.map(el => el.getAttribute('hreflang'))
    );
    for (const locale of LOCALES) {
      expect(hreflangs).toContain(locale);
    }
  });

  test('news listing page has hreflang alternates', async ({ page }) => {
    await page.goto('/en/news');
    const alternates = page.locator('link[rel="alternate"]');
    const count = await alternates.count();
    expect(count).toBeGreaterThanOrEqual(5);
  });
});

test.describe('Content translation fallback', () => {
  test('visiting French news shows French content if translated, English if not', async ({ page }) => {
    // The seed data populates English content. Some records may have French
    // translations if the admin added them. Either way, the page should render
    // without errors.
    const response = await page.goto('/fr/news');
    expect(response?.status()).toBe(200);

    // The news listing should show at least one article
    const articleCount = await page.locator('a[href*="/fr/news/"]').count();
    expect(articleCount).toBeGreaterThan(0);
  });

  test('detail page in French shows content (translated or fallback)', async ({ page }) => {
    // Get the first news article URL from the French listing
    await page.goto('/fr/news');
    const firstArticle = page.locator('a[href*="/fr/news/"]').first();
    await expect(firstArticle).toBeVisible({ timeout: 10000 });
    const href = await firstArticle.getAttribute('href');

    // Visit the French version of the detail page
    const response = await page.goto(href!);
    expect(response?.status()).toBe(200);

    // The article h1 should be visible (either French translation or English fallback)
    await expect(page.locator('h1').first()).toBeVisible();
    const h1Text = await page.locator('h1').first().textContent();
    expect(h1Text?.trim().length).toBeGreaterThan(0);
  });
});

test.describe('Locale-prefixed URLs for all listing pages', () => {
  // Verify each locale prefix works for each listing page
  const pages = ['news', 'programs', 'faculty', 'campus-life', 'testimonials', 'faq'];

  for (const locale of LOCALES) {
    for (const pageName of pages) {
      test(`${locale}/${pageName} returns 200`, async ({ page }) => {
        const response = await page.goto(`/${locale}/${pageName}`);
        expect(response?.status()).toBe(200);
      });
    }
  }
});

test.describe('HTML lang attribute', () => {
  for (const locale of LOCALES) {
    test(`<html lang="${locale}"> is set correctly`, async ({ page }) => {
      await page.goto(`/${locale}/`);
      const lang = await page.locator('html').getAttribute('lang');
      expect(lang).toBe(locale);
    });
  }
});
