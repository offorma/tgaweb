import { test, expect } from '@playwright/test';

/**
 * Smoke tests — verify all public pages load successfully.
 *
 * These tests run against a freshly-seeded database, so we know:
 *   - Site settings exist (singleton row)
 *   - At least one program, faculty member, news article, etc. exist
 *   - Hero slides are seeded
 *
 * If a test fails here, it usually means:
 *   - The build is broken (most common)
 *   - The database wasn't seeded (check the CI workflow logs)
 *   - A schema migration changed something (check prisma/schema.prisma)
 */

const LOCALES = ['en', 'fr', 'ha', 'ig', 'yo'];

test.describe('Homepage loads in all locales', () => {
  for (const locale of LOCALES) {
    test(`homepage renders in ${locale.toUpperCase()}`, async ({ page }) => {
      await page.goto(`/${locale}/`);

      // Hero should be visible
      await expect(page.locator('section#home, header').first()).toBeVisible({ timeout: 15000 });

      // Title should contain the school name
      await expect(page).toHaveTitle(/Trail Gliders/i);

      // Screenshot for visual diff (saved to test-results/output/)
      await page.screenshot({ path: `test-results/output/home-${locale}.png`, fullPage: false });
    });
  }
});

test.describe('Public listing pages load', () => {
  for (const locale of LOCALES) {
    test(`${locale}/news loads`, async ({ page }) => {
      const response = await page.goto(`/${locale}/news`);
      expect(response?.status()).toBe(200);
      // Should have at least one news article card
      await expect(page.locator('article, [class*="rounded-3xl"]').first()).toBeVisible({ timeout: 10000 });
    });

    test(`${locale}/programs loads`, async ({ page }) => {
      const response = await page.goto(`/${locale}/programs`);
      expect(response?.status()).toBe(200);
    });

    test(`${locale}/faculty loads`, async ({ page }) => {
      const response = await page.goto(`/${locale}/faculty`);
      expect(response?.status()).toBe(200);
    });

    test(`${locale}/campus-life loads`, async ({ page }) => {
      const response = await page.goto(`/${locale}/campus-life`);
      expect(response?.status()).toBe(200);
    });

    test(`${locale}/testimonials loads`, async ({ page }) => {
      const response = await page.goto(`/${locale}/testimonials`);
      expect(response?.status()).toBe(200);
    });

    test(`${locale}/faq loads`, async ({ page }) => {
      const response = await page.goto(`/${locale}/faq`);
      expect(response?.status()).toBe(200);
    });
  }
});

test.describe('Detail pages load (using seeded data)', () => {
  test('English news detail page loads', async ({ page }) => {
    // Go to news listing first, find the first article link
    await page.goto('/en/news');
    const firstArticle = page.locator('a[href*="/news/"]').first();
    await expect(firstArticle).toBeVisible({ timeout: 10000 });
    const href = await firstArticle.getAttribute('href');

    // Visit the detail page
    const response = await page.goto(href!);
    expect(response?.status()).toBe(200);

    // Article title should be visible
    await expect(page.locator('h1').first()).toBeVisible();
  });

  test('English program detail page loads', async ({ page }) => {
    await page.goto('/en/programs');
    const firstProgram = page.locator('a[href*="/programs/"]').first();
    await expect(firstProgram).toBeVisible({ timeout: 10000 });
    const href = await firstProgram.getAttribute('href');

    const response = await page.goto(href!);
    expect(response?.status()).toBe(200);
    await expect(page.locator('h1').first()).toBeVisible();
  });

  test('English faculty detail page loads', async ({ page }) => {
    await page.goto('/en/faculty');
    const firstFaculty = page.locator('a[href*="/faculty/"]').first();
    await expect(firstFaculty).toBeVisible({ timeout: 10000 });
    const href = await firstFaculty.getAttribute('href');

    const response = await page.goto(href!);
    expect(response?.status()).toBe(200);
    await expect(page.locator('h1').first()).toBeVisible();
  });
});

test.describe('Homepage sections render', () => {
  test('all homepage sections are present', async ({ page }) => {
    await page.goto('/en/');

    // Check key sections exist (by anchor id)
    for (const sectionId of ['home', 'about', 'campus-life', 'news', 'contact']) {
      const section = page.locator(`#${sectionId}`).first();
      await expect(section).toBeVisible({ timeout: 10000 });
    }
  });

  test('navbar is sticky and visible', async ({ page }) => {
    await page.goto('/en/');
    const header = page.locator('header').first();
    await expect(header).toBeVisible();
    // Scroll down — navbar should remain visible (sticky)
    await page.evaluate(() => window.scrollTo(0, 1000));
    await expect(header).toBeVisible();
  });

  test('footer is present with contact info', async ({ page }) => {
    await page.goto('/en/');
    const footer = page.locator('footer').first();
    await expect(footer).toBeVisible();
    // Should contain email or phone
    const footerText = await footer.textContent();
    expect(footerText).toMatch(/@|tel:|\+\d/);
  });
});

test.describe('API health', () => {
  test('unauthenticated admin API returns 401', async ({ request }) => {
    const response = await request.get('/api/admin/me');
    expect(response.status()).toBe(401);
  });

  test('contact API rejects empty body', async ({ request }) => {
    const response = await request.post('/api/contact', {
      data: {},
    });
    // Should return 400 (bad request) — not 500 (server error)
    expect([400, 422]).toContain(response.status());
  });

  test('captcha API returns a challenge', async ({ request }) => {
    const response = await request.get('/api/captcha');
    // 200 or 400 are both fine (depends on implementation); 500 is a bug
    expect(response.status()).toBeLessThan(500);
  });
});

test.describe('404 handling', () => {
  test('unknown news slug returns 404', async ({ page }) => {
    const response = await page.goto('/en/news/this-slug-does-not-exist-xyz123');
    expect(response?.status()).toBe(404);
  });

  test('unknown program slug returns 404', async ({ page }) => {
    const response = await page.goto('/en/programs/nonexistent-program-abc');
    expect(response?.status()).toBe(404);
  });
});
