import { defineConfig, devices } from '@playwright/test';

/**
 * Playwright configuration for Trail Gliders Academy E2E tests.
 *
 * Tests run against a local Next.js server (started by the CI workflow).
 * The CI workflow seeds a fresh Postgres database before tests run.
 *
 * Run locally:
 *   1. Start a Postgres instance and set DATABASE_URL
 *   2. npm run db:push && npm run db:seed
 *   3. npm run build
 *   4. (cd .next/standalone && PORT=3000 node server.js &)
 *   5. npx playwright test
 *
 * In CI, all of the above is handled by .github/workflows/e2e.yml.
 */
export default defineConfig({
  testDir: './e2e',
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 1 : 0,
  workers: process.env.CI ? 1 : undefined,
  reporter: [
    ['html', { outputFolder: 'playwright-report', open: 'never' }],
    ['list'],
    ['junit', { outputFile: 'results.xml' }],
  ],
  outputDir: 'test-results/output',

  use: {
    baseURL: process.env.BASE_URL || 'http://localhost:3000',
    trace: 'on-first-retry',
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
    // Set a longer timeout for cold-start builds
    actionTimeout: 15_000,
    navigationTimeout: 30_000,
  },

  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },
    // Uncomment to test on more browsers (slower, more CI minutes)
    // {
    //   name: 'firefox',
    //   use: { ...devices['Desktop Firefox'] },
    // },
    // {
    //   name: 'mobile-chrome',
    //   use: { ...devices['Pixel 5'] },
    // },
  ],

  // We don't use Playwright's built-in webServer because the CI workflow
  // starts the Next.js server manually (with specific env vars + DB seeding).
  // For local development, start the server manually before running tests.
});
