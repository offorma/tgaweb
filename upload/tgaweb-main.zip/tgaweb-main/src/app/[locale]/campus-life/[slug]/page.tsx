import { notFound } from "next/navigation";
import { Link } from "@/i18n/routing";
import { Clock, User, ArrowRight } from "lucide-react";
import { getTranslations, setRequestLocale } from "next-intl/server";
import type { Metadata } from "next";
import {
  getCampusItemBySlug,
  getCampusItems,
  getSiteSettings,
} from "@/lib/content";
import { DetailPageShell } from "@/components/site/detail-page-shell";
import { ArticleBody } from "@/components/site/article-body";
import { ImageGallery } from "@/components/site/image-gallery";

export const revalidate = 60;

interface PageProps {
  params: Promise<{ locale: string; slug: string }>;
}

export async function generateMetadata({
  params,
}: PageProps): Promise<Metadata> {
  const { locale, slug } = await params;
  void locale;
  const item = await getCampusItemBySlug(slug);
  if (!item) return { title: "Campus feature not found" };
  return {
    title: item.title,
    description: item.description,
    openGraph: {
      title: item.title,
      description: item.description,
      images: item.image ? [{ url: item.image }] : undefined,
    },
  };
}

export default async function CampusLifeDetailPage({ params }: PageProps) {
  const { locale, slug } = await params;
  setRequestLocale(locale);
  const t = await getTranslations("campusDetail");
  const item = await getCampusItemBySlug(slug);

  if (!item) notFound();

  const settings = await getSiteSettings();
  const allItems = await getCampusItems();
  const related = allItems.filter((i) => i.id !== item.id).slice(0, 3);

  return (
    <DetailPageShell
      backHref="/campus-life"
      backLabelKey="campusDetail.backToCampus"
      settings={settings}
    >
      <article className="py-12 lg:py-16">
        <div className="max-w-5xl mx-auto px-6">
          {/* Header */}
          <header className="mb-8">
            <div className="text-xs font-bold uppercase tracking-[0.18em] text-[var(--orange-dark)]">
              {t("campusLife")}
            </div>
            <h1 className="mt-3 font-serif font-bold text-4xl sm:text-5xl lg:text-6xl text-[var(--navy)] leading-[1.1] text-balance">
              {item.title}
            </h1>
            <p className="mt-4 text-xl text-muted-foreground leading-relaxed">
              {item.description}
            </p>
          </header>

          {/* Hero image */}
          {item.image && (
            <div className="relative aspect-[16/9] overflow-hidden rounded-2xl shadow-xl mb-10">
              <img
                src={item.image}
                alt={item.title}
                className="absolute inset-0 h-full w-full object-cover"
              />
            </div>
          )}

          {/* Quick info */}
          {(item.schedule || item.coach) && (
            <div className="grid sm:grid-cols-2 gap-4 mb-10">
              {item.schedule && (
                <div className="bg-[var(--cream)]/50 rounded-xl p-4">
                  <div className="text-xs font-bold uppercase tracking-wider text-muted-foreground inline-flex items-center gap-1">
                    <Clock className="h-3 w-3" /> {t("schedule")}
                  </div>
                  <div className="mt-1 font-serif text-lg text-[var(--navy)] whitespace-pre-line">
                    {item.schedule}
                  </div>
                </div>
              )}
              {item.coach && (
                <div className="bg-[var(--cream)]/50 rounded-xl p-4">
                  <div className="text-xs font-bold uppercase tracking-wider text-muted-foreground inline-flex items-center gap-1">
                    <User className="h-3 w-3" /> {t("coach")}
                  </div>
                  <div className="mt-1 font-serif text-lg text-[var(--navy)]">
                    {item.coach}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Body */}
          {item.body && (
            <div className="mb-10">
              <ArticleBody content={item.body} />
            </div>
          )}

          {/* Gallery */}
          {item.gallery && (
            <div className="mb-10 pt-10 border-t border-black/10">
              <h3 className="font-serif text-2xl font-bold text-[var(--navy)] mb-5">
                {t("gallery")}
              </h3>
              <ImageGallery images={item.gallery} />
            </div>
          )}

          {/* CTA */}
          <div className="mt-12 p-8 lg:p-10 bg-gradient-to-br from-[var(--orange)] to-[var(--orange-dark)] rounded-2xl text-center text-white">
            <h3 className="font-serif text-2xl lg:text-3xl font-bold">
              {t("ctaTitle")}
            </h3>
            <p className="mt-3 text-white/90 max-w-xl mx-auto">
              {t("ctaDescription")}
            </p>
            <Link
              href="/#contact"
              className="mt-6 inline-flex items-center gap-2 px-6 py-3 rounded-full bg-white text-[var(--orange-dark)] font-semibold hover:bg-white/90 transition-colors"
            >
              {t("ctaButton")}
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>

        {/* Related */}
        {related.length > 0 && (
          <section className="mt-16 pt-12 border-t border-black/10 bg-[var(--cream)]/30">
            <div className="max-w-5xl mx-auto px-6">
              <h2 className="font-serif text-2xl lg:text-3xl font-bold text-[var(--navy)] mb-8">
                {t("exploreMore")}
              </h2>
              <div className="grid md:grid-cols-3 gap-6">
                {related.map((r) => (
                  <Link
                    key={r.id}
                    href={`/campus-life/${r.slug}`}
                    className="group bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-xl transition-all"
                  >
                    <div className="relative aspect-[16/10] overflow-hidden">
                      <img
                        src={r.image}
                        alt={r.title}
                        className="absolute inset-0 h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
                      />
                    </div>
                    <div className="p-5">
                      <h3 className="font-serif text-lg font-bold text-[var(--navy)] group-hover:text-[var(--orange-dark)] transition-colors">
                        {r.title}
                      </h3>
                      <p className="mt-1 text-sm text-muted-foreground line-clamp-2">
                        {r.description}
                      </p>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          </section>
        )}
      </article>
    </DetailPageShell>
  );
}
