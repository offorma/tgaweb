import { notFound } from "next/navigation";
import { Link } from "@/i18n/routing";
import { Quote, Mail, Award, BookOpen, Calendar } from "lucide-react";
import { getTranslations, setRequestLocale } from "next-intl/server";
import type { Metadata } from "next";
import { getFacultyBySlug, getFaculty, getSiteSettings } from "@/lib/content";
import { t as tt } from "@/lib/i18n-content";
import { DetailPageShell } from "@/components/site/detail-page-shell";
import { ArticleBody } from "@/components/site/article-body";
import { ImageGallery } from "@/components/site/image-gallery";

export const revalidate = 60;

interface PageProps {
  params: Promise<{ locale: string; slug: string }>;
}

export async function generateMetadata({
  params,
}: PageProps): Promise<Metadata> {
  const { locale, slug } = await params;
  const item = await getFacultyBySlug(slug);
  if (!item) return { title: "Faculty not found" };
  return {
    title: `${item.name} — ${item.role}`,
    description: item.bio,
    openGraph: {
      title: item.name,
      description: item.bio,
      images: item.image ? [{ url: item.image }] : undefined,
    },
  };
}

export default async function FacultyProfilePage({ params }: PageProps) {
  const { locale, slug } = await params;
  setRequestLocale(locale);
  const t = await getTranslations("facultyDetail");
  const member = await getFacultyBySlug(slug);

  if (!member) notFound();

  const settings = await getSiteSettings();
  const allFaculty = await getFaculty();
  const related = allFaculty.filter((f) => f.id !== member.id).slice(0, 4);
  const qualifications = member.qualifications.split("\n").map((s) => s.trim()).filter(Boolean);
  const subjects = member.subjects.split("\n").map((s) => s.trim()).filter(Boolean);

  return (
    <DetailPageShell
      backHref="/faculty"
      backLabelKey="facultyDetail.backToFaculty"
      settings={settings}
    >
      <article className="py-12 lg:py-16">
        <div className="max-w-5xl mx-auto px-6">
          {/* Header */}
          <header className="grid md:grid-cols-3 gap-8 mb-12">
            <div className="md:col-span-1">
              <div className="relative aspect-[4/5] rounded-2xl overflow-hidden shadow-xl">
                <img
                  src={member.image}
                  alt={member.name}
                  className="absolute inset-0 h-full w-full object-cover"
                />
              </div>
            </div>
            <div className="md:col-span-2 flex flex-col justify-center">
              <div className="text-xs font-bold uppercase tracking-[0.18em] text-[var(--orange-dark)]">
                {t("ourFaculty")}
              </div>
              <h1 className="mt-3 font-serif font-bold text-4xl lg:text-5xl text-[var(--navy)] leading-tight">
                {member.name}
              </h1>
              <p className="mt-2 text-xl text-[var(--orange-dark)] font-semibold">
                {tt(member.roleI18n as any, member.role, locale)}
              </p>
              {member.yearsTeaching > 0 && (
                <p className="mt-3 inline-flex items-center gap-1.5 text-sm text-muted-foreground">
                  <Calendar className="h-4 w-4" />
                  {t("yearsTeaching", { years: member.yearsTeaching })}
                </p>
              )}
              {member.email && (
                <a
                  href={`mailto:${member.email}`}
                  className="mt-4 inline-flex items-center gap-2 text-sm font-medium text-[var(--navy)] hover:text-[var(--orange-dark)] transition-colors"
                >
                  <Mail className="h-4 w-4" />
                  {member.email}
                </a>
              )}
              {member.quote && (
                <div className="mt-6 relative pl-6 border-l-4 border-[var(--orange)]">
                  <Quote className="absolute -top-2 -left-3 h-6 w-6 text-[var(--orange)] fill-[var(--orange)]/20" />
                  <p className="font-serif italic text-lg text-[var(--navy)] leading-relaxed">
                    {tt(member.quoteI18n as any, member.quote, locale)}
                  </p>
                </div>
              )}
            </div>
          </header>

          {/* Bio */}
          {member.bio && (
            <div className="mb-10">
              <h2 className="font-serif text-2xl font-bold text-[var(--navy)] mb-4">
                {t("about")}
              </h2>
              <p className="text-lg text-muted-foreground leading-relaxed whitespace-pre-line">
                {tt(member.bioI18n as any, member.bio, locale)}
              </p>
            </div>
          )}

          {/* Qualifications + Subjects grid */}
          <div className="grid md:grid-cols-2 gap-8 mb-10">
            {qualifications.length > 0 && (
              <div>
                <h3 className="font-serif text-xl font-bold text-[var(--navy)] mb-4 inline-flex items-center gap-2">
                  <Award className="h-5 w-5 text-[var(--orange-dark)]" />
                  {t("qualifications")}
                </h3>
                <ul className="space-y-2">
                  {qualifications.map((q, i) => (
                    <li key={i} className="flex items-start gap-2 text-muted-foreground">
                      <span className="mt-2 h-1.5 w-1.5 rounded-full bg-[var(--orange)] flex-shrink-0" />
                      {q}
                    </li>
                  ))}
                </ul>
              </div>
            )}
            {subjects.length > 0 && (
              <div>
                <h3 className="font-serif text-xl font-bold text-[var(--navy)] mb-4 inline-flex items-center gap-2">
                  <BookOpen className="h-5 w-5 text-[var(--orange-dark)]" />
                  {t("subjectsTaught")}
                </h3>
                <div className="flex flex-wrap gap-2">
                  {subjects.map((s, i) => (
                    <span
                      key={i}
                      className="px-3 py-1.5 rounded-full bg-[var(--cream)] text-sm font-medium text-[var(--navy)] border border-black/5"
                    >
                      {s}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Gallery */}
          {member.gallery && (
            <div className="mb-10 pt-10 border-t border-black/10">
              <h3 className="font-serif text-2xl font-bold text-[var(--navy)] mb-5">
                {t("gallery")}
              </h3>
              <ImageGallery images={member.gallery} />
            </div>
          )}
        </div>

        {/* Related faculty */}
        {related.length > 0 && (
          <section className="mt-16 pt-12 border-t border-black/10 bg-[var(--cream)]/30">
            <div className="max-w-5xl mx-auto px-6">
              <h2 className="font-serif text-2xl lg:text-3xl font-bold text-[var(--navy)] mb-8">
                {t("meetMore")}
              </h2>
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
                {related.map((f) => (
                  <Link
                    key={f.id}
                    href={`/faculty/${f.slug}`}
                    className="group text-center"
                  >
                    <div className="relative aspect-square rounded-2xl overflow-hidden shadow-md group-hover:shadow-xl transition-shadow">
                      <img
                        src={f.image}
                        alt={f.name}
                        className="absolute inset-0 h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
                      />
                    </div>
                    <h3 className="mt-3 font-serif text-base font-bold text-[var(--navy)] group-hover:text-[var(--orange-dark)] transition-colors">
                      {f.name}
                    </h3>
                    <p className="text-xs text-muted-foreground">{tt(f.roleI18n as any, f.role, locale)}</p>
                  </Link>
                ))}
              </div>
            </div>
          </section>
        )}
      </article>
    </DetailPageShell>
  );
}
