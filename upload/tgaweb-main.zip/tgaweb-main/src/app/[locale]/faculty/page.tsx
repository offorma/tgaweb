import { Link } from "@/i18n/routing";
import { getTranslations, setRequestLocale } from "next-intl/server";
import type { Metadata } from "next";
import { getFaculty, getSiteSettings } from "@/lib/content";
import { t as tt } from "@/lib/i18n-content";
import { Navbar } from "@/components/site/navbar";
import { Footer } from "@/components/site/footer";
import { PageHeader } from "@/components/site/page-header";

export const revalidate = 60;

interface PageProps {
  params: Promise<{ locale: string }>;
}

export async function generateMetadata(): Promise<Metadata> {
  return {
    title: "Our Faculty",
    description: "Meet the dedicated educators of Trail Gliders Academy.",
  };
}

export default async function FacultyListingPage({ params }: PageProps) {
  const { locale } = await params;
  setRequestLocale(locale);
  const t = await getTranslations("faculty");
  const td = await getTranslations("facultyDetail");
  const faculty = await getFaculty();
  const settings = await getSiteSettings();

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar settings={settings} />
      <main className="flex-1">
        <PageHeader
          badge={t("badge")}
          title1={t("title1")}
          title2={t("title2")}
          description={t("description")}
        />

        <section className="py-16 lg:py-20">
          <div className="max-w-7xl mx-auto px-6">
            {faculty.length === 0 ? (
              <p className="text-center text-muted-foreground py-20">
                {td("noFaculty")}
              </p>
            ) : (
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
                {faculty.map((member) => (
                  <Link
                    key={member.id}
                    href={`/faculty/${member.slug}`}
                    className="group bg-white rounded-3xl overflow-hidden shadow-md hover:shadow-2xl transition-all duration-500"
                  >
                    <div className="relative aspect-[4/5] overflow-hidden">
                      <img
                        src={member.image}
                        alt={member.name}
                        className="absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-[var(--navy-dark)]/90 via-transparent to-transparent" />
                      <div className="absolute bottom-0 inset-x-0 p-5 text-white">
                        <div className="text-[10px] uppercase tracking-[0.2em] text-[var(--orange-light)] font-semibold">
                          {tt(member.roleI18n as any, member.role, locale)}
                        </div>
                        <h3 className="mt-1 font-serif text-2xl font-bold">
                          {member.name}
                        </h3>
                        {member.bio && (
                          <p className="mt-2 text-sm text-white/80 line-clamp-2">
                            {tt(member.bioI18n as any, member.bio, locale)}
                          </p>
                        )}
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </div>
        </section>
      </main>
      <Footer settings={settings} />
    </div>
  );
}
