import { notFound } from "next/navigation";
import { Link } from "@/i18n/routing";
import { HelpCircle, ArrowRight } from "lucide-react";
import { getTranslations, setRequestLocale } from "next-intl/server";
import type { Metadata } from "next";
import { getFaqBySlug, getRelatedFaqs, getSiteSettings } from "@/lib/content";
import { DetailPageShell } from "@/components/site/detail-page-shell";
import { ArticleBody } from "@/components/site/article-body";

export const revalidate = 60;

interface PageProps {
  params: Promise<{ locale: string; slug: string }>;
}

export async function generateMetadata({
  params,
}: PageProps): Promise<Metadata> {
  const { locale, slug } = await params;
  void locale;
  const item = await getFaqBySlug(slug);
  if (!item) return { title: "FAQ not found" };
  return {
    title: item.question,
    description: item.answer,
  };
}

export default async function FaqDetailPage({ params }: PageProps) {
  const { locale, slug } = await params;
  setRequestLocale(locale);
  const t = await getTranslations("faqDetail");
  const item = await getFaqBySlug(slug);

  if (!item) notFound();

  const settings = await getSiteSettings();
  const related = await getRelatedFaqs(item.id, item.category, 5);

  return (
    <DetailPageShell
      backHref="/faq"
      backLabelKey="faqDetail.backToFaq"
      settings={settings}
    >
      <article className="py-12 lg:py-16">
        <div className="max-w-3xl mx-auto px-6">
          {/* Header */}
          <header className="mb-8">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[var(--orange)]/10 text-[var(--orange-dark)] text-xs font-bold uppercase tracking-wider">
              <HelpCircle className="h-3 w-3" />
              {item.category}
            </div>
            <h1 className="mt-4 font-serif font-bold text-3xl sm:text-4xl text-[var(--navy)] leading-tight text-balance">
              {item.question}
            </h1>
          </header>

          {/* Short answer */}
          <div className="p-6 rounded-2xl bg-[var(--cream)]/60 border border-black/5 mb-8">
            <div className="text-xs font-bold uppercase tracking-wider text-[var(--orange-dark)] mb-2">
              {t("quickAnswer")}
            </div>
            <p className="text-lg text-[var(--navy)] leading-relaxed">
              {item.answer}
            </p>
          </div>

          {/* Expanded answer */}
          {item.expanded && (
            <div className="pt-8 border-t border-black/10">
              <h2 className="font-serif text-2xl font-bold text-[var(--navy)] mb-4">
                {t("detailedAnswer")}
              </h2>
              <ArticleBody content={item.expanded} />
            </div>
          )}

          {/* Help CTA */}
          <div className="mt-12 p-8 bg-gradient-to-br from-[var(--navy)] to-[var(--navy-dark)] rounded-2xl text-center text-white">
            <h3 className="font-serif text-xl font-bold">
              {t("stillHaveQuestions")}
            </h3>
            <p className="mt-2 text-white/80 text-sm">
              {t("contactDescription")}
            </p>
            <Link
              href="/#contact"
              className="mt-5 inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-[var(--orange)] hover:bg-[var(--orange-dark)] text-white text-sm font-semibold transition-colors"
            >
              {t("contactUs")}
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>

        {/* Related FAQs */}
        {related.length > 0 && (
          <section className="mt-16 pt-12 border-t border-black/10 bg-[var(--cream)]/30">
            <div className="max-w-3xl mx-auto px-6">
              <h2 className="font-serif text-2xl lg:text-3xl font-bold text-[var(--navy)] mb-8">
                {t("relatedFaqs")}
              </h2>
              <div className="space-y-3">
                {related.map((r) => (
                  <Link
                    key={r.id}
                    href={`/faq/${r.slug}`}
                    className="group flex items-center justify-between gap-4 p-4 bg-white rounded-xl shadow-sm hover:shadow-md transition-all"
                  >
                    <div className="flex-1">
                      <div className="text-xs font-bold uppercase tracking-wider text-[var(--orange-dark)]">
                        {r.category}
                      </div>
                      <div className="mt-1 font-serif font-bold text-[var(--navy)] group-hover:text-[var(--orange-dark)] transition-colors">
                        {r.question}
                      </div>
                    </div>
                    <ArrowRight className="h-5 w-5 text-[var(--orange-dark)] group-hover:translate-x-1 transition-transform flex-shrink-0" />
                  </Link>
                ))}
              </div>
            </div>
          </section>
        )}
      </article>
    </DetailPageShell>
  );
}
