import { Link } from "@/i18n/routing";
import { ChevronRight, HelpCircle } from "lucide-react";
import { getTranslations, setRequestLocale } from "next-intl/server";
import type { Metadata } from "next";
import { getFaqs, getSiteSettings } from "@/lib/content";
import { Navbar } from "@/components/site/navbar";
import { Footer } from "@/components/site/footer";
import { PageHeader } from "@/components/site/page-header";
import { FaqAccordion } from "@/components/site/faq-accordion";

export const revalidate = 60;

interface PageProps {
  params: Promise<{ locale: string }>;
}

export async function generateMetadata(): Promise<Metadata> {
  return {
    title: "Frequently Asked Questions",
    description: "Answers to common questions about admissions, fees, curriculum, and more.",
  };
}

export default async function FaqListingPage({ params }: PageProps) {
  const { locale } = await params;
  setRequestLocale(locale);
  const t = await getTranslations("faq");
  const td = await getTranslations("faqDetail");
  const faqs = await getFaqs();
  const settings = await getSiteSettings();

  // Group by category
  const categories = Array.from(new Set(faqs.map((f) => f.category || "General")));
  const grouped = categories.map((cat) => ({
    category: cat,
    items: faqs.filter((f) => (f.category || "General") === cat),
  }));

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar settings={settings} />
      <main className="flex-1">
        <PageHeader
          badge={t("badge")}
          title1={t("title1")}
          title2={t("title2")}
          description={t("description")}
        />

        <section className="py-16 lg:py-20">
          <div className="max-w-3xl mx-auto px-6">
            {faqs.length === 0 ? (
              <p className="text-center text-muted-foreground py-20">
                {td("noFaqs")}
              </p>
            ) : (
              <div className="space-y-12">
                {grouped.map((group) => (
                  <div key={group.category}>
                    <h2 className="font-serif text-2xl font-bold text-[var(--navy)] mb-5 inline-flex items-center gap-2">
                      <HelpCircle className="h-6 w-6 text-[var(--orange-dark)]" />
                      {group.category}
                    </h2>
                    <FaqAccordion items={group.items} />
                  </div>
                ))}

                {/* Browse all link */}
                <div className="text-center pt-8">
                  <p className="text-sm text-muted-foreground">
                    {td("browseHint")}
                  </p>
                  <Link
                    href="/#faq"
                    className="mt-3 inline-flex items-center gap-1 text-sm font-semibold text-[var(--orange-dark)] hover:gap-2 transition-all"
                  >
                    {td("viewOnHomepage")}
                    <ChevronRight className="h-4 w-4" />
                  </Link>
                </div>
              </div>
            )}
          </div>
        </section>
      </main>
      <Footer settings={settings} />
    </div>
  );
}
