import { setRequestLocale } from "next-intl/server";
import { routing } from "@/i18n/routing";

/**
 * Locale layout — runs for every public page under /[locale]/...
 *
 * Calls `setRequestLocale()` so that all server components in this segment
 * know which locale to use for static rendering and ISR cache keys.
 *
 * The root layout at src/app/layout.tsx handles <html> and <body>.
 */
export function generateStaticParams() {
  return routing.locales.map((locale) => ({ locale }));
}

export default async function LocaleLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  // Enable static rendering for this locale
  setRequestLocale(locale);
  return <>{children}</>;
}
