import { notFound } from "next/navigation";
import { Link } from "@/i18n/routing";
import { Calendar, Tag, User, ArrowRight } from "lucide-react";
import { getTranslations, setRequestLocale } from "next-intl/server";
import type { Metadata } from "next";
import {
  getNewsBySlug,
  getRelatedNews,
  getSiteSettings,
} from "@/lib/content";
import { t as tt } from "@/lib/i18n-content";
import { DetailPageShell } from "@/components/site/detail-page-shell";
import { ArticleBody } from "@/components/site/article-body";
import { ImageGallery } from "@/components/site/image-gallery";

export const revalidate = 60;

interface PageProps {
  params: Promise<{ locale: string; slug: string }>;
}

const DATE_LOCALE_MAP: Record<string, string> = {
  en: "en-GB",
  fr: "fr-FR",
  ha: "ha-NG",
  ig: "ig-NG",
  yo: "yo-NG",
};

function formatDate(iso: string | Date, locale: string) {
  const d = typeof iso === "string" ? new Date(iso) : iso;
  return d.toLocaleDateString(DATE_LOCALE_MAP[locale] || "en-GB", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });
}

export async function generateMetadata({
  params,
}: PageProps): Promise<Metadata> {
  const { locale, slug } = await params;
  const item = await getNewsBySlug(slug);
  if (!item) return { title: "Article not found" };
  return {
    title: item.title,
    description: item.excerpt,
    openGraph: {
      title: item.title,
      description: item.excerpt,
      type: "article",
      publishedTime: item.date.toISOString(),
      images: item.image ? [{ url: item.image }] : undefined,
    },
    twitter: {
      card: "summary_large_image",
      title: item.title,
      description: item.excerpt,
      images: item.image ? [item.image] : undefined,
    },
  };
}

export default async function NewsArticlePage({ params }: PageProps) {
  const { locale, slug } = await params;
  setRequestLocale(locale);
  const t = await getTranslations("newsDetail");
  const item = await getNewsBySlug(slug);

  if (!item || !item.published) notFound();

  const related = await getRelatedNews(item.id, item.category, 3);
  const settings = await getSiteSettings();

  return (
    <DetailPageShell
      backHref="/news"
      backLabelKey="newsDetail.backToNews"
      settings={settings}
    >
      <article className="py-12 lg:py-16">
        <div className="max-w-3xl mx-auto px-6">
          {/* Header */}
          <header className="mb-8">
            <div className="flex items-center gap-3 text-xs font-bold uppercase tracking-[0.18em] text-[var(--orange-dark)]">
              <span className="inline-flex items-center gap-1.5">
                <Tag className="h-3 w-3" />
                {item.category}
              </span>
              {item.tag && (
                <>
                  <span className="text-black/20">•</span>
                  <span>{item.tag}</span>
                </>
              )}
            </div>

            <h1 className="mt-4 font-serif font-bold text-4xl sm:text-5xl text-[var(--navy)] leading-[1.15] text-balance">
              {tt(item.titleI18n as any, item.title, locale)}
            </h1>

            <div className="mt-6 flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
              <span className="inline-flex items-center gap-1.5">
                <Calendar className="h-4 w-4" />
                {formatDate(item.date, locale)}
              </span>
              {item.author && (
                <span className="inline-flex items-center gap-1.5">
                  <User className="h-4 w-4" />
                  {item.author}
                </span>
              )}
            </div>
          </header>

          {/* Hero image */}
          {item.image && (
            <div className="relative aspect-[16/9] overflow-hidden rounded-2xl shadow-xl mb-10">
              <img
                src={item.image}
                alt={tt(item.titleI18n as any, item.title, locale)}
                className="absolute inset-0 h-full w-full object-cover"
              />
            </div>
          )}

          {/* Excerpt as lead */}
          {item.excerpt && (
            <p className="text-xl font-medium text-[var(--navy)] leading-relaxed mb-8 pb-8 border-b border-black/10">
              {tt(item.excerptI18n as any, item.excerpt, locale)}
            </p>
          )}

          {/* Body */}
          {item.body ? (
            <ArticleBody content={tt(item.bodyI18n as any, item.body, locale)} />
          ) : (
            <p className="text-muted-foreground italic">
              {t("noBody")}
            </p>
          )}

          {/* Gallery */}
          {item.gallery && (
            <div className="mt-10 pt-10 border-t border-black/10">
              <h3 className="font-serif text-2xl font-bold text-[var(--navy)] mb-5">
                {t("gallery")}
              </h3>
              <ImageGallery images={item.gallery} />
            </div>
          )}
        </div>

        {/* Related articles */}
        {related.length > 0 && (
          <section className="mt-16 pt-12 border-t border-black/10 bg-[var(--cream)]/30">
            <div className="max-w-5xl mx-auto px-6">
              <h2 className="font-serif text-2xl lg:text-3xl font-bold text-[var(--navy)] mb-8">
                {t("relatedArticles")}
              </h2>
              <div className="grid md:grid-cols-3 gap-6">
                {related.map((r) => (
                  <Link
                    key={r.id}
                    href={`/news/${r.slug}`}
                    className="group bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-xl transition-all duration-300"
                  >
                    <div className="relative aspect-[16/10] overflow-hidden">
                      <img
                        src={r.image}
                        alt={tt(r.titleI18n as any, r.title, locale)}
                        className="absolute inset-0 h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
                      />
                    </div>
                    <div className="p-5">
                      <div className="text-[10px] font-bold uppercase tracking-[0.18em] text-[var(--orange-dark)]">
                        {r.category}
                      </div>
                      <h3 className="mt-2 font-serif text-base font-bold text-[var(--navy)] leading-snug group-hover:text-[var(--orange-dark)] transition-colors line-clamp-2">
                        {tt(r.titleI18n as any, r.title, locale)}
                      </h3>
                      <div className="mt-3 inline-flex items-center gap-1 text-xs font-semibold text-[var(--orange-dark)] group-hover:gap-2 transition-all">
                        {t("readMore")}
                        <ArrowRight className="h-3 w-3" />
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          </section>
        )}
      </article>
    </DetailPageShell>
  );
}
