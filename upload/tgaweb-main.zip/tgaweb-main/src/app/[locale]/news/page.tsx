import { Link } from "@/i18n/routing";
import { Calendar, Tag, ArrowRight } from "lucide-react";
import { getTranslations, setRequestLocale } from "next-intl/server";
import type { Metadata } from "next";
import { getPublishedNews, getSiteSettings } from "@/lib/content";
import { t as tt } from "@/lib/i18n-content";
import { Navbar } from "@/components/site/navbar";
import { Footer } from "@/components/site/footer";
import { PageHeader } from "@/components/site/page-header";

export const revalidate = 60;

interface PageProps {
  params: Promise<{ locale: string }>;
}

const DATE_LOCALE_MAP: Record<string, string> = {
  en: "en-GB",
  fr: "fr-FR",
  ha: "ha-NG",
  ig: "ig-NG",
  yo: "yo-NG",
};

function formatDate(iso: string | Date, locale: string) {
  const d = typeof iso === "string" ? new Date(iso) : iso;
  return d.toLocaleDateString(DATE_LOCALE_MAP[locale] || "en-GB", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

export async function generateMetadata(): Promise<Metadata> {
  return {
    title: "News & Events",
    description: "Latest news and upcoming events at Trail Gliders Academy.",
  };
}

export default async function NewsListingPage({ params }: PageProps) {
  const { locale } = await params;
  setRequestLocale(locale);
  const t = await getTranslations("news");
  const td = await getTranslations("newsDetail");
  const news = await getPublishedNews();
  const settings = await getSiteSettings();

  const featured = news[0];
  const rest = news.slice(1);

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar settings={settings} />
      <main className="flex-1">
        <PageHeader
          badge={t("badge")}
          title1={t("title1")}
          title2={t("title2")}
          description={t("description")}
        />

        <section className="py-16 lg:py-20">
          <div className="max-w-7xl mx-auto px-6">
            {news.length === 0 ? (
              <p className="text-center text-muted-foreground py-20">
                {td("noNews")}
              </p>
            ) : (
              <>
                {/* Featured article */}
                {featured && (
                  <Link
                    href={`/news/${featured.slug}`}
                    className="group block mb-16"
                  >
                    <div className="grid lg:grid-cols-2 gap-8 items-center bg-white rounded-3xl overflow-hidden shadow-lg hover:shadow-2xl transition-shadow duration-500">
                      <div className="relative aspect-[16/10] lg:aspect-auto lg:h-full overflow-hidden">
                        <img
                          src={featured.image}
                          alt={tt(featured.titleI18n as any, featured.title, locale)}
                          className="absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                        />
                        <div className="absolute top-4 left-4 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/95 backdrop-blur-sm text-[10px] font-bold uppercase tracking-wider text-[var(--navy)]">
                          <span className="h-1.5 w-1.5 rounded-full bg-[var(--orange)]" />
                          {td("featured")}
                        </div>
                      </div>
                      <div className="p-8 lg:p-12">
                        <div className="flex items-center gap-3 text-xs font-bold uppercase tracking-[0.18em] text-[var(--orange-dark)]">
                          <span className="inline-flex items-center gap-1.5">
                            <Tag className="h-3 w-3" />
                            {featured.category}
                          </span>
                          {featured.tag && (
                            <>
                              <span className="text-black/20">•</span>
                              <span>{featured.tag}</span>
                            </>
                          )}
                        </div>
                        <h2 className="mt-3 font-serif text-3xl lg:text-4xl font-bold text-[var(--navy)] leading-tight group-hover:text-[var(--orange-dark)] transition-colors">
                          {tt(featured.titleI18n as any, featured.title, locale)}
                        </h2>
                        <p className="mt-4 text-muted-foreground leading-relaxed line-clamp-3">
                          {tt(featured.excerptI18n as any, featured.excerpt, locale)}
                        </p>
                        <div className="mt-6 flex items-center gap-4 text-sm text-muted-foreground">
                          <span className="inline-flex items-center gap-1.5">
                            <Calendar className="h-4 w-4" />
                            {formatDate(featured.date, locale)}
                          </span>
                        </div>
                        <div className="mt-6 inline-flex items-center gap-1.5 text-sm font-semibold text-[var(--orange-dark)] group-hover:gap-2.5 transition-all">
                          {td("readMore")}
                          <ArrowRight className="h-4 w-4" />
                        </div>
                      </div>
                    </div>
                  </Link>
                )}

                {/* Grid of remaining articles */}
                {rest.length > 0 && (
                  <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {rest.map((item) => (
                      <Link
                        key={item.id}
                        href={`/news/${item.slug}`}
                        className="group bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 flex flex-col"
                      >
                        <div className="relative aspect-[16/10] overflow-hidden">
                          <img
                            src={item.image}
                            alt={tt(item.titleI18n as any, item.title, locale)}
                            className="absolute inset-0 h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
                          />
                          <div className="absolute top-3 left-3 inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-white/95 backdrop-blur-sm text-[10px] font-bold uppercase tracking-wider text-[var(--navy)]">
                            <span className="h-1.5 w-1.5 rounded-full bg-[var(--orange)]" />
                            {item.tag}
                          </div>
                        </div>
                        <div className="p-5 flex-1 flex flex-col">
                          <div className="text-xs font-bold uppercase tracking-[0.18em] text-[var(--orange-dark)]">
                            {item.category}
                          </div>
                          <h3 className="mt-2 font-serif text-lg font-bold text-[var(--navy)] leading-snug group-hover:text-[var(--orange-dark)] transition-colors line-clamp-2">
                            {tt(item.titleI18n as any, item.title, locale)}
                          </h3>
                          <p className="mt-2 text-sm text-muted-foreground leading-relaxed line-clamp-2 flex-1">
                            {tt(item.excerptI18n as any, item.excerpt, locale)}
                          </p>
                          <div className="mt-4 flex items-center justify-between text-xs text-muted-foreground">
                            <span className="inline-flex items-center gap-1.5">
                              <Calendar className="h-3 w-3" />
                              {formatDate(item.date, locale)}
                            </span>
                            <span className="inline-flex items-center gap-1 text-[var(--orange-dark)] font-semibold group-hover:gap-1.5 transition-all">
                              {td("readMore")}
                              <ArrowRight className="h-3 w-3" />
                            </span>
                          </div>
                        </div>
                      </Link>
                    ))}
                  </div>
                )}
              </>
            )}
          </div>
        </section>
      </main>
      <Footer settings={settings} />
    </div>
  );
}
