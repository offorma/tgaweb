import { Link } from "@/i18n/routing";
import { Home, ArrowRight } from "lucide-react";
import { Navbar } from "@/components/site/navbar";
import { Footer } from "@/components/site/footer";
import { getSiteSettings } from "@/lib/content";

export const revalidate = 60;

export default async function NotFound() {
  const settings = await getSiteSettings();

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar settings={settings} />
      <main className="flex-1 flex items-center justify-center bg-mesh-cream">
        <div className="max-w-xl mx-auto px-6 py-20 text-center">
          <div className="font-serif text-8xl lg:text-9xl font-bold gradient-text-orange leading-none">
            404
          </div>
          <h1 className="mt-4 font-serif text-3xl font-bold text-[var(--navy)]">
            Page not found
          </h1>
          <p className="mt-3 text-muted-foreground">
            The page you&rsquo;re looking for doesn&rsquo;t exist, has been moved, or the
            link is broken. Let&rsquo;s get you back on track.
          </p>

          <div className="mt-8 grid sm:grid-cols-2 gap-3">
            <Link
              href="/"
              className="inline-flex items-center justify-center gap-2 px-5 py-3 rounded-full bg-[var(--navy)] hover:bg-[var(--navy-dark)] text-white font-semibold transition-colors"
            >
              <Home className="h-4 w-4" />
              Back to homepage
            </Link>
            <Link
              href="/news"
              className="inline-flex items-center justify-center gap-2 px-5 py-3 rounded-full bg-white hover:bg-[var(--cream)] text-[var(--navy)] font-semibold border border-black/10 transition-colors"
            >
              Browse news
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>

          <div className="mt-10 pt-8 border-t border-black/10">
            <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-4">
              Or explore
            </p>
            <div className="flex flex-wrap justify-center gap-2">
              {[
                { label: "Programs", href: "/programs" },
                { label: "Faculty", href: "/faculty" },
                { label: "Campus Life", href: "/campus-life" },
                { label: "Testimonials", href: "/testimonials" },
                { label: "FAQ", href: "/faq" },
              ].map((l) => (
                <Link
                  key={l.href}
                  href={l.href}
                  className="px-4 py-2 rounded-full bg-white border border-black/5 text-sm font-medium text-[var(--navy)] hover:text-[var(--orange-dark)] hover:border-[var(--orange)]/30 transition-colors"
                >
                  {l.label}
                </Link>
              ))}
            </div>
          </div>
        </div>
      </main>
      <Footer settings={settings} />
    </div>
  );
}
