import { notFound } from "next/navigation";
import { Link } from "@/i18n/routing";
import { Check, Clock, User, ArrowRight, BookOpen } from "lucide-react";
import { getTranslations, setRequestLocale } from "next-intl/server";
import type { Metadata } from "next";
import { getProgramBySlug, getPrograms, getSiteSettings } from "@/lib/content";
import { t as tt } from "@/lib/i18n-content";
import { DetailPageShell } from "@/components/site/detail-page-shell";
import { ArticleBody } from "@/components/site/article-body";
import { ImageGallery } from "@/components/site/image-gallery";
import { cn } from "@/lib/utils";

export const revalidate = 60;

interface PageProps {
  params: Promise<{ locale: string; slug: string }>;
}

const COLOR_STYLES: Record<string, { bg: string; text: string; ring: string }> = {
  orange: { bg: "bg-[var(--orange)]", text: "text-[var(--orange-dark)]", ring: "ring-[var(--orange)]/30" },
  navy: { bg: "bg-[var(--navy)]", text: "text-[var(--navy)]", ring: "ring-[var(--navy)]/30" },
  gold: { bg: "bg-[var(--gold)]", text: "text-[var(--gold)]", ring: "ring-[var(--gold)]/30" },
};

export async function generateMetadata({
  params,
}: PageProps): Promise<Metadata> {
  const { locale, slug } = await params;
  const item = await getProgramBySlug(slug);
  if (!item) return { title: "Program not found" };
  return {
    title: item.name,
    description: item.tagline || item.description,
    openGraph: {
      title: item.name,
      description: item.tagline || item.description,
      images: item.image ? [{ url: item.image }] : undefined,
    },
  };
}

export default async function ProgramDetailPage({ params }: PageProps) {
  const { locale, slug } = await params;
  setRequestLocale(locale);
  const t = await getTranslations("programDetail");
  const program = await getProgramBySlug(slug);

  if (!program) notFound();

  const settings = await getSiteSettings();
  const allPrograms = await getPrograms();
  const related = allPrograms.filter((p) => p.id !== program.id).slice(0, 3);
  const featuresStr = tt(program.featuresI18n as any, program.features, locale);
  const features = featuresStr.split("\n").map((s) => s.trim()).filter(Boolean);
  const curriculum = program.curriculum.split("\n").map((s) => s.trim()).filter(Boolean);
  const color = COLOR_STYLES[program.color] || COLOR_STYLES.orange;

  return (
    <DetailPageShell
      backHref="/programs"
      backLabelKey="programDetail.backToPrograms"
      settings={settings}
    >
      <article className="py-12 lg:py-16">
        <div className="max-w-5xl mx-auto px-6">
          {/* Header */}
          <header className="mb-10">
            <div className="flex items-center gap-3 text-xs font-bold uppercase tracking-[0.18em]">
              <span className={cn("inline-flex items-center gap-1.5 px-3 py-1 rounded-full", color.bg, "text-white")}>
                {program.ages}
              </span>
              {program.tag && (
                <span className="text-[var(--orange-dark)]">{program.tag}</span>
              )}
            </div>
            <h1 className="mt-5 font-serif font-bold text-4xl sm:text-5xl lg:text-6xl text-[var(--navy)] leading-[1.1] text-balance">
              {tt(program.nameI18n as any, program.name, locale)}
            </h1>
            {program.tagline && (
              <p className="mt-4 text-xl text-muted-foreground leading-relaxed">
                {tt(program.taglineI18n as any, program.tagline, locale)}
              </p>
            )}
          </header>

          {/* Hero image */}
          {program.image && (
            <div className="relative aspect-[16/9] overflow-hidden rounded-2xl shadow-xl mb-10">
              <img
                src={program.image}
                alt={tt(program.nameI18n as any, program.name, locale)}
                className="absolute inset-0 h-full w-full object-cover"
              />
            </div>
          )}

          {/* Quick info bar */}
          <div className="grid sm:grid-cols-3 gap-4 mb-10">
            <div className="bg-[var(--cream)]/50 rounded-xl p-4">
              <div className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
                {t("ages")}
              </div>
              <div className="mt-1 font-serif text-lg text-[var(--navy)]">{program.ages}</div>
            </div>
            {program.leadFaculty && (
              <div className="bg-[var(--cream)]/50 rounded-xl p-4">
                <div className="text-xs font-bold uppercase tracking-wider text-muted-foreground inline-flex items-center gap-1">
                  <User className="h-3 w-3" /> {t("leadTeacher")}
                </div>
                <div className="mt-1 font-serif text-lg text-[var(--navy)]">{program.leadFaculty}</div>
              </div>
            )}
            {program.schedule && (
              <div className="bg-[var(--cream)]/50 rounded-xl p-4">
                <div className="text-xs font-bold uppercase tracking-wider text-muted-foreground inline-flex items-center gap-1">
                  <Clock className="h-3 w-3" /> {t("schedule")}
                </div>
                <div className="mt-1 font-serif text-lg text-[var(--navy)]">{program.schedule}</div>
              </div>
            )}
          </div>

          {/* Description */}
          {program.description && (
            <div className="mb-10">
              <h2 className="font-serif text-2xl font-bold text-[var(--navy)] mb-4">
                {t("overview")}
              </h2>
              <p className="text-lg text-muted-foreground leading-relaxed">
                {tt(program.descriptionI18n as any, program.description, locale)}
              </p>
            </div>
          )}

          {/* Features */}
          {features.length > 0 && (
            <div className="mb-10">
              <h2 className="font-serif text-2xl font-bold text-[var(--navy)] mb-5">
                {t("keyFeatures")}
              </h2>
              <div className="grid sm:grid-cols-2 gap-3">
                {features.map((f, i) => (
                  <div
                    key={i}
                    className="flex items-start gap-2.5 p-3 rounded-lg bg-white border border-black/5"
                  >
                    <div className={cn("mt-0.5 h-5 w-5 rounded-full flex items-center justify-center flex-shrink-0", color.bg)}>
                      <Check className="h-3 w-3 text-white" />
                    </div>
                    <span className="text-[var(--navy)] font-medium">{f}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Curriculum */}
          {curriculum.length > 0 && (
            <div className="mb-10">
              <h2 className="font-serif text-2xl font-bold text-[var(--navy)] mb-2 inline-flex items-center gap-2">
                <BookOpen className={cn("h-6 w-6", color.text)} />
                {t("curriculum")}
              </h2>
              <p className="text-sm text-muted-foreground mb-5">{t("curriculumDescription")}</p>
              <ol className="space-y-3">
                {curriculum.map((c, i) => (
                  <li
                    key={i}
                    className="flex items-start gap-4 p-4 rounded-lg bg-[var(--cream)]/40 border border-black/5"
                  >
                    <div className={cn("flex-shrink-0 h-9 w-9 rounded-full flex items-center justify-center font-bold text-white text-sm", color.bg)}>
                      {String(i + 1).padStart(2, "0")}
                    </div>
                    <div className="pt-1 text-[var(--navy)]">{c}</div>
                  </li>
                ))}
              </ol>
            </div>
          )}

          {/* Body (rich text) */}
          {program.body && (
            <div className="mb-10">
              <ArticleBody content={tt(program.bodyI18n as any, program.body, locale)} />
            </div>
          )}

          {/* Gallery */}
          {program.gallery && (
            <div className="mb-10 pt-10 border-t border-black/10">
              <h3 className="font-serif text-2xl font-bold text-[var(--navy)] mb-5">
                {t("gallery")}
              </h3>
              <ImageGallery images={program.gallery} />
            </div>
          )}

          {/* CTA */}
          <div className="mt-12 p-8 lg:p-10 bg-gradient-to-br from-[var(--navy)] to-[var(--navy-dark)] rounded-2xl text-center text-white">
            <h3 className="font-serif text-2xl lg:text-3xl font-bold">
              {t("ctaTitle")}
            </h3>
            <p className="mt-3 text-white/80 max-w-xl mx-auto">
              {t("ctaDescription")}
            </p>
            <Link
              href="/#contact"
              className="mt-6 inline-flex items-center gap-2 px-6 py-3 rounded-full bg-[var(--orange)] hover:bg-[var(--orange-dark)] text-white font-semibold transition-colors"
            >
              {t("ctaButton")}
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>

        {/* Related programs */}
        {related.length > 0 && (
          <section className="mt-16 pt-12 border-t border-black/10 bg-[var(--cream)]/30">
            <div className="max-w-5xl mx-auto px-6">
              <h2 className="font-serif text-2xl lg:text-3xl font-bold text-[var(--navy)] mb-8">
                {t("otherPrograms")}
              </h2>
              <div className="grid md:grid-cols-3 gap-6">
                {related.map((p) => (
                  <Link
                    key={p.id}
                    href={`/programs/${p.slug}`}
                    className="group bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-xl transition-all"
                  >
                    <div className="relative aspect-[16/10] overflow-hidden">
                      <img
                        src={p.image}
                        alt={tt(p.nameI18n as any, p.name, locale)}
                        className="absolute inset-0 h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
                      />
                    </div>
                    <div className="p-5">
                      <div className="text-xs font-bold uppercase tracking-wider text-[var(--orange-dark)]">
                        {p.ages}
                      </div>
                      <h3 className="mt-2 font-serif text-lg font-bold text-[var(--navy)] group-hover:text-[var(--orange-dark)] transition-colors">
                        {tt(p.nameI18n as any, p.name, locale)}
                      </h3>
                      <p className="mt-1 text-sm text-muted-foreground line-clamp-2">
                        {tt(p.taglineI18n as any, p.tagline, locale)}
                      </p>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          </section>
        )}
      </article>
    </DetailPageShell>
  );
}
