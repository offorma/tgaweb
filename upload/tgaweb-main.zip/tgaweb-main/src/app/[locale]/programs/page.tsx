import { Link } from "@/i18n/routing";
import { ArrowRight } from "lucide-react";
import { getTranslations, setRequestLocale } from "next-intl/server";
import type { Metadata } from "next";
import { getPrograms, getSiteSettings } from "@/lib/content";
import { t as tt } from "@/lib/i18n-content";
import { Navbar } from "@/components/site/navbar";
import { Footer } from "@/components/site/footer";
import { PageHeader } from "@/components/site/page-header";
import { cn } from "@/lib/utils";

export const revalidate = 60;

interface PageProps {
  params: Promise<{ locale: string }>;
}

const COLOR_STYLES: Record<string, string> = {
  orange: "from-[var(--orange)] to-[var(--orange-dark)]",
  navy: "from-[var(--navy)] to-[var(--navy-dark)]",
  gold: "from-[var(--gold)] to-[var(--orange)]",
};

export async function generateMetadata(): Promise<Metadata> {
  return {
    title: "Academic Programs",
    description: "Explore our academic programs from Nursery through Primary 6.",
  };
}

export default async function ProgramsListingPage({ params }: PageProps) {
  const { locale } = await params;
  setRequestLocale(locale);
  const t = await getTranslations("academics");
  const td = await getTranslations("programDetail");
  const programs = await getPrograms();
  const settings = await getSiteSettings();

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar settings={settings} />
      <main className="flex-1">
        <PageHeader
          badge={t("badge")}
          title1={t("title1")}
          title2={t("title2")}
          description={t("description")}
        />

        <section className="py-16 lg:py-20">
          <div className="max-w-7xl mx-auto px-6">
            {programs.length === 0 ? (
              <p className="text-center text-muted-foreground py-20">
                {td("noPrograms")}
              </p>
            ) : (
              <div className="grid lg:grid-cols-2 gap-8">
                {programs.map((p) => (
                  <Link
                    key={p.id}
                    href={`/programs/${p.slug}`}
                    className="group bg-white rounded-3xl overflow-hidden shadow-md hover:shadow-2xl transition-all duration-500"
                  >
                    <div className="grid sm:grid-cols-5">
                      <div className="relative sm:col-span-2 aspect-[4/3] sm:aspect-auto overflow-hidden">
                        <img
                          src={p.image}
                          alt={tt(p.nameI18n as any, p.name, locale)}
                          className="absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                        />
                        <div
                          className={cn(
                            "absolute top-3 left-3 px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider text-white bg-gradient-to-r",
                            COLOR_STYLES[p.color] || COLOR_STYLES.orange,
                          )}
                        >
                          {p.ages}
                        </div>
                      </div>
                      <div className="sm:col-span-3 p-6 lg:p-7 flex flex-col">
                        <h3 className="font-serif text-2xl font-bold text-[var(--navy)] group-hover:text-[var(--orange-dark)] transition-colors">
                          {tt(p.nameI18n as any, p.name, locale)}
                        </h3>
                        <p className="mt-2 text-sm text-muted-foreground leading-relaxed line-clamp-2 flex-1">
                          {tt(p.taglineI18n as any, p.tagline, locale) || tt(p.descriptionI18n as any, p.description, locale)}
                        </p>
                        <div className="mt-4 inline-flex items-center gap-1.5 text-sm font-semibold text-[var(--orange-dark)] group-hover:gap-2.5 transition-all">
                          {td("learnMore")}
                          <ArrowRight className="h-4 w-4" />
                        </div>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </div>
        </section>
      </main>
      <Footer settings={settings} />
    </div>
  );
}
