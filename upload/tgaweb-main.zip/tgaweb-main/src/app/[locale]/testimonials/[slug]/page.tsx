import { notFound } from "next/navigation";
import { Link } from "@/i18n/routing";
import { Quote, Star } from "lucide-react";
import { getTranslations, setRequestLocale } from "next-intl/server";
import type { Metadata } from "next";
import {
  getTestimonialBySlug,
  getTestimonials,
  getSiteSettings,
} from "@/lib/content";
import { DetailPageShell } from "@/components/site/detail-page-shell";

export const revalidate = 60;

interface PageProps {
  params: Promise<{ locale: string; slug: string }>;
}

export async function generateMetadata({
  params,
}: PageProps): Promise<Metadata> {
  const { locale, slug } = await params;
  void locale;
  const item = await getTestimonialBySlug(slug);
  if (!item) return { title: "Testimonial not found" };
  return {
    title: `${item.name} — Testimonial`,
    description: item.quote,
    openGraph: {
      title: `${item.name} — Testimonial`,
      description: item.quote,
      images: item.image ? [{ url: item.image }] : undefined,
    },
  };
}

export default async function TestimonialDetailPage({ params }: PageProps) {
  const { locale, slug } = await params;
  setRequestLocale(locale);
  const t = await getTranslations("testimonialDetail");
  const item = await getTestimonialBySlug(slug);

  if (!item) notFound();

  const settings = await getSiteSettings();
  const all = await getTestimonials();
  const related = all.filter((i) => i.id !== item.id).slice(0, 3);

  return (
    <DetailPageShell
      backHref="/testimonials"
      backLabelKey="testimonialDetail.backToTestimonials"
      settings={settings}
    >
      <article className="py-12 lg:py-20">
        <div className="max-w-3xl mx-auto px-6">
          {/* Header */}
          <div className="text-center mb-10">
            <Quote className="h-12 w-12 text-[var(--orange)] fill-[var(--orange)]/20 mx-auto" />
            <div className="mt-6 flex justify-center gap-0.5">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star
                  key={i}
                  className={
                    i < item.rating
                      ? "h-5 w-5 text-[var(--gold)] fill-[var(--gold)]"
                      : "h-5 w-5 text-black/10"
                  }
                />
              ))}
            </div>
          </div>

          {/* Quote */}
          <blockquote className="font-serif text-2xl sm:text-3xl lg:text-4xl text-[var(--navy)] leading-[1.4] text-center text-balance">
            &ldquo;{item.quote}&rdquo;
          </blockquote>

          {/* Author */}
          <div className="mt-10 flex flex-col items-center text-center">
            {item.image ? (
              <div className="h-20 w-20 rounded-full overflow-hidden ring-4 ring-[var(--orange)]/30 mb-4">
                <img
                  src={item.image}
                  alt={item.name}
                  className="h-full w-full object-cover"
                />
              </div>
            ) : (
              <div className="h-20 w-20 rounded-full bg-gradient-to-br from-[var(--orange)] to-[var(--orange-dark)] text-white flex items-center justify-center font-serif text-2xl font-bold mb-4 ring-4 ring-[var(--orange)]/30">
                {item.name.charAt(0)}
              </div>
            )}
            <div className="font-serif text-xl font-bold text-[var(--navy)]">
              {item.name}
            </div>
            <div className="text-sm text-muted-foreground">{item.relation}</div>
            {item.childName && (
              <div className="mt-1 text-sm text-muted-foreground">
                {t("parentOf", { name: item.childName })}
              </div>
            )}
            {item.yearEnrolled && (
              <div className="mt-1 text-xs font-bold uppercase tracking-wider text-[var(--orange-dark)]">
                {t("enrolled", { year: item.yearEnrolled })}
              </div>
            )}
          </div>

          {/* Full story */}
          {item.fullStory && (
            <div className="mt-12 pt-10 border-t border-black/10">
              <h2 className="font-serif text-2xl font-bold text-[var(--navy)] mb-4">
                {t("fullStory")}
              </h2>
              <p className="text-lg text-muted-foreground leading-relaxed whitespace-pre-line">
                {item.fullStory}
              </p>
            </div>
          )}
        </div>

        {/* Related testimonials */}
        {related.length > 0 && (
          <section className="mt-16 pt-12 border-t border-black/10 bg-[var(--cream)]/30">
            <div className="max-w-5xl mx-auto px-6">
              <h2 className="font-serif text-2xl lg:text-3xl font-bold text-[var(--navy)] mb-8 text-center">
                {t("moreTestimonials")}
              </h2>
              <div className="grid md:grid-cols-3 gap-6">
                {related.map((r) => (
                  <Link
                    key={r.id}
                    href={`/testimonials/${r.slug}`}
                    className="group bg-white rounded-2xl p-6 shadow-md hover:shadow-xl transition-all"
                  >
                    <Quote className="h-6 w-6 text-[var(--orange)] fill-[var(--orange)]/20" />
                    <p className="mt-3 text-sm text-muted-foreground line-clamp-4 italic">
                      &ldquo;{r.quote}&rdquo;
                    </p>
                    <div className="mt-4 font-serif font-bold text-[var(--navy)] group-hover:text-[var(--orange-dark)] transition-colors">
                      {r.name}
                    </div>
                    <div className="text-xs text-muted-foreground">{r.relation}</div>
                  </Link>
                ))}
              </div>
            </div>
          </section>
        )}
      </article>
    </DetailPageShell>
  );
}
