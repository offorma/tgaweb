import { Link } from "@/i18n/routing";
import { Quote, Star } from "lucide-react";
import { getTranslations, setRequestLocale } from "next-intl/server";
import type { Metadata } from "next";
import { getTestimonials, getSiteSettings } from "@/lib/content";
import { Navbar } from "@/components/site/navbar";
import { Footer } from "@/components/site/footer";
import { PageHeader } from "@/components/site/page-header";

export const revalidate = 60;

interface PageProps {
  params: Promise<{ locale: string }>;
}

export async function generateMetadata(): Promise<Metadata> {
  return {
    title: "Testimonials",
    description: "Read what parents and pupils say about Trail Gliders Academy.",
  };
}

export default async function TestimonialsListingPage({ params }: PageProps) {
  const { locale } = await params;
  setRequestLocale(locale);
  const t = await getTranslations("testimonials");
  const td = await getTranslations("testimonialDetail");
  const items = await getTestimonials();
  const settings = await getSiteSettings();

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar settings={settings} />
      <main className="flex-1">
        <PageHeader
          badge={t("badge")}
          title1={t("title1")}
          title2={t("title2")}
          description={t("description")}
        />

        <section className="py-16 lg:py-20 bg-mesh-cream">
          <div className="max-w-7xl mx-auto px-6">
            {items.length === 0 ? (
              <p className="text-center text-muted-foreground py-20">
                {td("noTestimonials")}
              </p>
            ) : (
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {items.map((item) => (
                  <Link
                    key={item.id}
                    href={`/testimonials/${item.slug}`}
                    className="group bg-white rounded-2xl p-6 shadow-md hover:shadow-xl transition-all duration-300 flex flex-col"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <Quote className="h-7 w-7 text-[var(--orange)] fill-[var(--orange)]/20 flex-shrink-0" />
                      <div className="flex gap-0.5">
                        {Array.from({ length: 5 }).map((_, i) => (
                          <Star
                            key={i}
                            className={
                              i < item.rating
                                ? "h-3.5 w-3.5 text-[var(--gold)] fill-[var(--gold)]"
                                : "h-3.5 w-3.5 text-black/10"
                            }
                          />
                        ))}
                      </div>
                    </div>
                    <p className="mt-4 text-[var(--navy)] leading-relaxed line-clamp-4 italic flex-1">
                      &ldquo;{item.quote}&rdquo;
                    </p>
                    <div className="mt-5 pt-5 border-t border-black/5 flex items-center gap-3">
                      {item.image ? (
                        <div className="h-10 w-10 rounded-full overflow-hidden flex-shrink-0">
                          <img
                            src={item.image}
                            alt={item.name}
                            className="h-full w-full object-cover"
                          />
                        </div>
                      ) : (
                        <div className="h-10 w-10 rounded-full bg-gradient-to-br from-[var(--orange)] to-[var(--orange-dark)] text-white flex items-center justify-center font-bold text-sm flex-shrink-0">
                          {item.name.charAt(0)}
                        </div>
                      )}
                      <div>
                        <div className="font-serif font-bold text-[var(--navy)] group-hover:text-[var(--orange-dark)] transition-colors">
                          {item.name}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {item.relation}
                        </div>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </div>
        </section>
      </main>
      <Footer settings={settings} />
    </div>
  );
}
