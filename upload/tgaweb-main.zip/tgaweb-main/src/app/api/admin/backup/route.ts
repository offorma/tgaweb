import { NextResponse } from "next/server";
import { execSync } from "child_process";
import { adminHandler } from "@/lib/admin-api";

export const GET = adminHandler(
  async () => {
    const dbUrl = process.env.DATABASE_URL || "";

    if (!dbUrl.startsWith("postgresql")) {
      return NextResponse.json(
        { error: "SQL backup is only supported for PostgreSQL databases." },
        { status: 400 },
      );
    }

    let url: URL;
    try {
      url = new URL(dbUrl);
    } catch {
      return NextResponse.json(
        { error: "Invalid DATABASE_URL" },
        { status: 500 },
      );
    }

    const host = url.hostname;
    const port = url.port || "5432";
    const user = url.username;
    const password = url.password;
    const dbName = url.pathname.replace("/", "");

    try {
      const sql = execSync(
        `pg_dump --host=${host} --port=${port} --username=${user} --dbname=${dbName} --no-owner --no-acl --clean --if-exists --format=plain`,
        {
          env: { ...process.env, PGPASSWORD: password },
          maxBuffer: 50 * 1024 * 1024, // 50MB
        },
      ).toString();

      const timestamp = new Date()
        .toISOString()
        .replace(/[:.]/g, "-")
        .slice(0, 19);
      const filename = `trail-gliders-backup-${timestamp}.sql`;

      return new Response(sql, {
        status: 200,
        headers: {
          "Content-Type": "application/sql",
          "Content-Disposition": `attachment; filename="${filename}"`,
        },
      });
    } catch (e: any) {
      console.error("[backup] pg_dump failed:", e.message);
      return NextResponse.json(
        {
          error:
            "Backup failed. Ensure pg_dump is available on the server.",
        },
        { status: 500 },
      );
    }
  },
  { method: "GET", requiredRole: "ADMIN" },
);
