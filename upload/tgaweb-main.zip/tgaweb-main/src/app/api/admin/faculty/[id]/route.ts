import { NextResponse } from "next/server";
import { makeCrudItemRoutes } from "@/lib/crud-factory";
import { FacultySchema } from "@/lib/validations/site";
import { adminHandler, parseJsonBody, isValidId } from "@/lib/admin-api";
import { invalidateCache } from "@/lib/content";
import { db } from "@/lib/db";
import { slugify, ensureUniqueSlug } from "@/lib/slug";

// GET (single) and DELETE are provided by the factory — unchanged.
// PUT is overridden below to support slug regeneration and i18n JSON fields.
const crud = makeCrudItemRoutes({
  model: "faculty",
  schema: FacultySchema,
  cacheKey: "faculty",
  entityName: "Faculty",
});

export const GET = crud.GET;
export const DELETE = crud.DELETE;

export const PUT = adminHandler(async (req, _user, ctx) => {
  const id = ctx.params?.id;
  if (!isValidId(id)) {
    return NextResponse.json({ error: "Invalid id" }, { status: 400 });
  }

  const requestBody = await parseJsonBody(req);
  const parsed = FacultySchema.partial().safeParse(requestBody);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Validation failed", details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  const data: Record<string, unknown> = { ...parsed.data };

  // Normalize i18n fields: undefined → leave alone, null/object → persist.
  if ("roleI18n" in data && data.roleI18n == null) data.roleI18n = null;
  if ("bioI18n" in data && data.bioI18n == null) data.bioI18n = null;
  if ("quoteI18n" in data && data.quoteI18n == null) data.quoteI18n = null;

  // Auto-regenerate slug only if the client explicitly sent an empty string.
  if (data.slug === "") {
    const existing = await db.faculty.findUnique({ where: { id } });
    const nameForSlug =
      (typeof data.name === "string" && data.name) ||
      (typeof data.role === "string" && data.role) ||
      existing?.name ||
      existing?.role ||
      "untitled";
    data.slug = await ensureUniqueSlug(
      slugify(nameForSlug),
      (s) => db.faculty.findUnique({ where: { slug: s } }),
      id
    );
  }

  const item = await db.faculty.update({ where: { id }, data });
  invalidateCache("faculty");
  return NextResponse.json({ item });
}, { method: "PUT" });
