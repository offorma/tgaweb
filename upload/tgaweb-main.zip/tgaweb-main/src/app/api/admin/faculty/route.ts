import { NextResponse } from "next/server";
import { makeCrudRoutes } from "@/lib/crud-factory";
import { FacultySchema } from "@/lib/validations/site";
import { adminHandler, parseJsonBody } from "@/lib/admin-api";
import { invalidateCache } from "@/lib/content";
import { db } from "@/lib/db";
import { slugify, ensureUniqueSlug } from "@/lib/slug";

// GET (list all) is provided by the factory — unchanged.
// POST is overridden below to auto-generate the slug and persist the i18n JSON fields.
const crud = makeCrudRoutes({
  model: "faculty",
  schema: FacultySchema,
  cacheKey: "faculty",
  entityName: "Faculty",
});

export const GET = crud.GET;

export const POST = adminHandler(async (req) => {
  const requestBody = await parseJsonBody(req);
  const parsed = FacultySchema.safeParse(requestBody);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Validation failed", details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  const { name, role, roleI18n, image, bio, bioI18n, quote, quoteI18n, order, slug } =
    parsed.data;

  // Auto-generate slug if not provided — keeps URLs stable & unique.
  // Falls back to the role if the name is somehow empty.
  let finalSlug = slug;
  if (!finalSlug) {
    finalSlug = await ensureUniqueSlug(
      slugify(name || role || "untitled"),
      (s) => db.faculty.findUnique({ where: { slug: s } })
    );
  }

  const item = await db.faculty.create({
    data: {
      slug: finalSlug,
      name,
      role,
      roleI18n: roleI18n ?? null,
      image,
      bio,
      bioI18n: bioI18n ?? null,
      quote,
      quoteI18n: quoteI18n ?? null,
      order: order ?? 0,
    },
  });

  invalidateCache("faculty");
  return NextResponse.json({ item }, { status: 201 });
}, { method: "POST" });
