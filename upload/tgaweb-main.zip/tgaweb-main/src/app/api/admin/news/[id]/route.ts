import { NextResponse } from "next/server";
import { makeCrudItemRoutes } from "@/lib/crud-factory";
import { NewsItemSchema } from "@/lib/validations/site";
import { adminHandler, parseJsonBody, isValidId } from "@/lib/admin-api";
import { invalidateCache } from "@/lib/content";
import { db } from "@/lib/db";
import { slugify, ensureUniqueSlug } from "@/lib/slug";

// GET (single) and DELETE are provided by the factory — unchanged.
// PUT is overridden below to support slug regeneration and i18n JSON fields.
const crud = makeCrudItemRoutes({
  model: "newsItem",
  schema: NewsItemSchema,
  cacheKey: "news",
  entityName: "NewsItem",
});

export const GET = crud.GET;
export const DELETE = crud.DELETE;

export const PUT = adminHandler(async (req, _user, ctx) => {
  const id = ctx.params?.id;
  if (!isValidId(id)) {
    return NextResponse.json({ error: "Invalid id" }, { status: 400 });
  }

  const requestBody = await parseJsonBody(req);
  const parsed = NewsItemSchema.partial().safeParse(requestBody);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Validation failed", details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  // Build the update payload from validated fields. Prisma treats `undefined`
  // as "skip this field", so only provided fields will be updated.
  const data: Record<string, unknown> = { ...parsed.data };

  // Normalize i18n fields: undefined → leave alone, null/object → persist.
  // (z.record(z.string()).nullish() already accepts null or undefined; this is a no-op
  // but documents intent and protects against future schema tweaks.)
  if ("titleI18n" in data && data.titleI18n == null) data.titleI18n = null;
  if ("excerptI18n" in data && data.excerptI18n == null) data.excerptI18n = null;
  if ("bodyI18n" in data && data.bodyI18n == null) data.bodyI18n = null;

  // Date string → Date object (Prisma accepts ISO strings, but be explicit)
  if (typeof data.date === "string") {
    data.date = new Date(data.date);
  }

  // Auto-regenerate slug only if the client explicitly sent an empty string.
  // (Slug is not in the editor form, so this branch rarely runs — but it lets
  //  an admin manually clear a slug and have it rebuilt from the title.)
  if (data.slug === "") {
    const existing = await db.newsItem.findUnique({ where: { id } });
    const titleForSlug =
      (typeof data.title === "string" && data.title) || existing?.title || "untitled";
    data.slug = await ensureUniqueSlug(
      slugify(titleForSlug),
      (s) => db.newsItem.findUnique({ where: { slug: s } }),
      id
    );
  }

  const item = await db.newsItem.update({ where: { id }, data });
  invalidateCache("news");
  return NextResponse.json({ item });
}, { method: "PUT" });
