import { NextResponse } from "next/server";
import { makeCrudRoutes } from "@/lib/crud-factory";
import { NewsItemSchema } from "@/lib/validations/site";
import { adminHandler, parseJsonBody } from "@/lib/admin-api";
import { invalidateCache } from "@/lib/content";
import { db } from "@/lib/db";
import { slugify, ensureUniqueSlug } from "@/lib/slug";

// GET (list all) is provided by the factory — unchanged.
// POST is overridden below to auto-generate the slug and persist the i18n JSON fields.
const crud = makeCrudRoutes({
  model: "newsItem",
  schema: NewsItemSchema,
  cacheKey: "news",
  entityName: "NewsItem",
});

export const GET = crud.GET;

export const POST = adminHandler(async (req) => {
  const requestBody = await parseJsonBody(req);
  const parsed = NewsItemSchema.safeParse(requestBody);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Validation failed", details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  const {
    title,
    titleI18n,
    excerpt,
    excerptI18n,
    body,
    bodyI18n,
    date,
    category,
    tag,
    image,
    published,
    order,
    slug,
  } = parsed.data;

  // Auto-generate slug if not provided — keeps URLs stable & unique.
  let finalSlug = slug;
  if (!finalSlug) {
    finalSlug = await ensureUniqueSlug(
      slugify(title),
      (s) => db.newsItem.findUnique({ where: { slug: s } })
    );
  }

  const item = await db.newsItem.create({
    data: {
      slug: finalSlug,
      title,
      titleI18n: titleI18n ?? null,
      excerpt,
      excerptI18n: excerptI18n ?? null,
      body: body ?? "",
      bodyI18n: bodyI18n ?? null,
      date: new Date(date),
      category,
      tag,
      image,
      published: published ?? true,
      order: order ?? 0,
    },
  });

  invalidateCache("news");
  return NextResponse.json({ item }, { status: 201 });
}, { method: "POST" });
