import { NextResponse } from "next/server";
import { makeCrudItemRoutes } from "@/lib/crud-factory";
import { ProgramSchema } from "@/lib/validations/site";
import { adminHandler, parseJsonBody, isValidId } from "@/lib/admin-api";
import { invalidateCache } from "@/lib/content";
import { db } from "@/lib/db";
import { slugify, ensureUniqueSlug } from "@/lib/slug";

// GET (single) and DELETE are provided by the factory — unchanged.
// PUT is overridden below to support slug regeneration and i18n JSON fields.
const crud = makeCrudItemRoutes({
  model: "program",
  schema: ProgramSchema,
  cacheKey: "programs",
  entityName: "Program",
});

export const GET = crud.GET;
export const DELETE = crud.DELETE;

export const PUT = adminHandler(async (req, _user, ctx) => {
  const id = ctx.params?.id;
  if (!isValidId(id)) {
    return NextResponse.json({ error: "Invalid id" }, { status: 400 });
  }

  const requestBody = await parseJsonBody(req);
  const parsed = ProgramSchema.partial().safeParse(requestBody);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Validation failed", details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  const data: Record<string, unknown> = { ...parsed.data };

  // Normalize i18n fields: undefined → leave alone, null/object → persist.
  if ("nameI18n" in data && data.nameI18n == null) data.nameI18n = null;
  if ("taglineI18n" in data && data.taglineI18n == null) data.taglineI18n = null;
  if ("descriptionI18n" in data && data.descriptionI18n == null) data.descriptionI18n = null;
  if ("featuresI18n" in data && data.featuresI18n == null) data.featuresI18n = null;
  if ("bodyI18n" in data && data.bodyI18n == null) data.bodyI18n = null;

  // Auto-regenerate slug only if the client explicitly sent an empty string.
  if (data.slug === "") {
    const existing = await db.program.findUnique({ where: { id } });
    const nameForSlug =
      (typeof data.name === "string" && data.name) || existing?.name || "untitled";
    data.slug = await ensureUniqueSlug(
      slugify(nameForSlug),
      (s) => db.program.findUnique({ where: { slug: s } }),
      id
    );
  }

  const item = await db.program.update({ where: { id }, data });
  invalidateCache("programs");
  return NextResponse.json({ item });
}, { method: "PUT" });
