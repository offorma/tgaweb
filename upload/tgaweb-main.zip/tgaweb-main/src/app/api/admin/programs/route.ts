import { NextResponse } from "next/server";
import { makeCrudRoutes } from "@/lib/crud-factory";
import { ProgramSchema } from "@/lib/validations/site";
import { adminHandler, parseJsonBody } from "@/lib/admin-api";
import { invalidateCache } from "@/lib/content";
import { db } from "@/lib/db";
import { slugify, ensureUniqueSlug } from "@/lib/slug";

// GET (list all) is provided by the factory — unchanged.
// POST is overridden below to auto-generate the slug and persist the i18n JSON fields.
const crud = makeCrudRoutes({
  model: "program",
  schema: ProgramSchema,
  cacheKey: "programs",
  entityName: "Program",
});

export const GET = crud.GET;

export const POST = adminHandler(async (req) => {
  const requestBody = await parseJsonBody(req);
  const parsed = ProgramSchema.safeParse(requestBody);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Validation failed", details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  const {
    name,
    nameI18n,
    ages,
    image,
    color,
    tagline,
    taglineI18n,
    description,
    descriptionI18n,
    features,
    featuresI18n,
    body,
    bodyI18n,
    order,
    slug,
  } = parsed.data;

  // Auto-generate slug if not provided — keeps URLs stable & unique.
  let finalSlug = slug;
  if (!finalSlug) {
    finalSlug = await ensureUniqueSlug(
      slugify(name),
      (s) => db.program.findUnique({ where: { slug: s } })
    );
  }

  const item = await db.program.create({
    data: {
      slug: finalSlug,
      name,
      nameI18n: nameI18n ?? null,
      ages,
      image,
      color: color ?? "orange",
      tagline,
      taglineI18n: taglineI18n ?? null,
      description,
      descriptionI18n: descriptionI18n ?? null,
      features,
      featuresI18n: featuresI18n ?? null,
      body: body ?? "",
      bodyI18n: bodyI18n ?? null,
      order: order ?? 0,
    },
  });

  invalidateCache("programs");
  return NextResponse.json({ item }, { status: 201 });
}, { method: "POST" });
