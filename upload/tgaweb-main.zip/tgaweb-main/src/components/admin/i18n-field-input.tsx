"use client";

import { useState } from "react";
import { cn } from "@/lib/utils";
import { LOCALES, LOCALE_LABELS, type I18nField, type Locale } from "@/lib/i18n-content";
import { Globe, Check, AlertCircle } from "lucide-react";

/**
 * Reusable tabbed input for translatable fields.
 *
 * Shows 5 tabs (EN/FR/HA/IG/YO). The English tab edits the source field
 * (the original String column). The other 4 tabs edit the i18n JSON field.
 *
 * When a non-English tab is empty, a small badge shows "Falls back to English"
 * so the admin knows visitors in that language will see English.
 *
 * Usage:
 *   <I18nFieldInput
 *     label="Title"
 *     englishValue={item.title}
 *     i18nValue={item.titleI18n as I18nField}
 *     onEnglishChange={(v) => update({ title: v })}
 *     onI18nChange={(i18n) => update({ titleI18n: i18n })}
 *     multiline={false}
 *   />
 *
 * For long-text fields (news body, program description):
 *   <I18nFieldInput ... multiline rows={8} />
 */
interface I18nFieldInputProps {
  label: string;
  englishValue: string;
  i18nValue: I18nField;
  onEnglishChange: (value: string) => void;
  onI18nChange: (value: I18nField) => void;
  multiline?: boolean;
  rows?: number;
  placeholder?: string;
  description?: string;
  required?: boolean;
}

export function I18nFieldInput({
  label,
  englishValue,
  i18nValue,
  onEnglishChange,
  onI18nChange,
  multiline = false,
  rows = 4,
  placeholder,
  description,
  required,
}: I18nFieldInputProps) {
  const [activeTab, setActiveTab] = useState<Locale>("en");

  // Ensure i18nValue is an object (not null)
  const i18n: Record<string, string> = i18nValue ? { ...i18nValue } : {};

  const handleTabChange = (locale: Locale) => setActiveTab(locale);

  const handleEnglishChange = (value: string) => onEnglishChange(value);

  const handleI18nChange = (locale: Locale, value: string) => {
    const updated = { ...i18n, [locale]: value };
    onI18nChange(updated);
  };

  // Check which translations are present (non-empty)
  const hasTranslation = (locale: Locale): boolean => {
    if (locale === "en") return Boolean(englishValue?.trim());
    return Boolean(i18n[locale]?.trim());
  };

  const currentValue =
    activeTab === "en" ? englishValue : (i18n[activeTab] || "");

  const InputComponent = multiline ? "textarea" : "input";

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between gap-2">
        <label className="text-sm font-semibold text-[var(--navy)] flex items-center gap-1.5">
          <Globe className="h-3.5 w-3.5 text-[var(--orange-dark)]" />
          {label}
          {required && <span className="text-red-500">*</span>}
        </label>
        {description && (
          <span className="text-xs text-muted-foreground">{description}</span>
        )}
      </div>

      {/* Tabs */}
      <div className="flex flex-wrap gap-1 border-b border-black/10">
        {LOCALES.map((locale) => {
          const info = LOCALE_LABELS[locale];
          const isActive = activeTab === locale;
          const isTranslated = hasTranslation(locale);
          return (
            <button
              key={locale}
              type="button"
              onClick={() => handleTabChange(locale)}
              className={cn(
                "px-3 py-1.5 text-xs font-semibold border-b-2 -mb-px transition-colors flex items-center gap-1.5",
                isActive
                  ? "border-[var(--orange)] text-[var(--orange-dark)]"
                  : "border-transparent text-muted-foreground hover:text-[var(--navy)]",
              )}
            >
              <span>{info.flag}</span>
              <span>{locale.toUpperCase()}</span>
              {locale === "en" && (
                <span className="text-[9px] uppercase tracking-wider text-muted-foreground">
                  source
                </span>
              )}
              {locale !== "en" && isTranslated && (
                <Check className="h-3 w-3 text-green-600" />
              )}
              {locale !== "en" && !isTranslated && (
                <AlertCircle className="h-3 w-3 text-amber-500" />
              )}
            </button>
          );
        })}
      </div>

      {/* Input */}
      <InputComponent
        type={multiline ? undefined : "text"}
        rows={multiline ? rows : undefined}
        value={currentValue}
        onChange={(e) =>
          activeTab === "en"
            ? handleEnglishChange(e.target.value)
            : handleI18nChange(activeTab, e.target.value)
        }
        placeholder={placeholder || `Enter ${LOCALE_LABELS[activeTab].name} text...`}
        className="w-full px-3 py-2 rounded-md border border-black/15 bg-white text-sm text-[var(--navy)] focus:outline-none focus:ring-2 focus:ring-[var(--orange)] focus:border-[var(--orange)] resize-y"
      />

      {/* Helper text */}
      {activeTab !== "en" && !currentValue?.trim() && (
        <p className="text-xs text-amber-600 flex items-center gap-1">
          <AlertCircle className="h-3 w-3" />
          Empty — visitors in {LOCALE_LABELS[activeTab].name} will see the English version
          ({englishValue ? `"${englishValue.slice(0, 40)}${englishValue.length > 40 ? "..." : ""}"` : "also empty"})
        </p>
      )}
      {activeTab === "en" && (
        <p className="text-xs text-muted-foreground">
          English is the source — other languages fall back to this when missing
        </p>
      )}
    </div>
  );
}
