import ReactMarkdown from "react-markdown";
import { cn } from "@/lib/utils";

/**
 * Render markdown / rich-text content for detail pages.
 *
 * Supports standard markdown: headings, bold/italic, lists, links, images,
 * blockquotes, code blocks, horizontal rules.
 *
 * Styling follows the site's typography (Playfair Display for headings,
 * Plus Jakarta Sans for body) via Tailwind prose-like classes.
 */
export function ArticleBody({
  content,
  className,
}: {
  content: string;
  className?: string;
}) {
  if (!content || !content.trim()) return null;

  return (
    <div
      className={cn(
        // Prose-like styling without @tailwindcss/typography dependency
        "text-[var(--navy)] leading-relaxed",
        // Headings
        "[&_h1]:font-serif [&_h1]:text-4xl [&_h1]:font-bold [&_h1]:mt-8 [&_h1]:mb-4 [&_h1]:text-[var(--navy)]",
        "[&_h2]:font-serif [&_h2]:text-3xl [&_h2]:font-bold [&_h2]:mt-8 [&_h2]:mb-4 [&_h2]:text-[var(--navy)]",
        "[&_h3]:font-serif [&_h3]:text-2xl [&_h3]:font-semibold [&_h3]:mt-6 [&_h3]:mb-3 [&_h3]:text-[var(--navy)]",
        "[&_h4]:font-serif [&_h4]:text-xl [&_h4]:font-semibold [&_h4]:mt-4 [&_h4]:mb-2 [&_h4]:text-[var(--navy)]",
        // Paragraphs
        "[&_p]:text-base [&_p]:leading-[1.8] [&_p]:mb-5 [&_p]:text-muted-foreground",
        // Lists
        "[&_ul]:list-disc [&_ul]:pl-6 [&_ul]:mb-5 [&_ul]:space-y-2 [&_ul]:text-muted-foreground",
        "[&_ol]:list-decimal [&_ol]:pl-6 [&_ol]:mb-5 [&_ol]:space-y-2 [&_ol]:text-muted-foreground",
        "[&_li]:text-base [&_li]:leading-[1.7]",
        // Links
        "[&_a]:text-[var(--orange-dark)] [&_a]:font-semibold [&_a]:underline [&_a]:decoration-[var(--orange)]/40 [&_a]:underline-offset-2 [&_a]:hover:decoration-[var(--orange)] [&_a]:transition-colors",
        // Blockquotes
        "[&_blockquote]:border-l-4 [&_blockquote]:border-[var(--orange)] [&_blockquote]:bg-[var(--cream)]/50 [&_blockquote]:pl-5 [&_blockquote]:pr-4 [&_blockquote]:py-3 [&_blockquote]:my-6 [&_blockquote]:rounded-r-lg [&_blockquote]:italic [&_blockquote]:text-[var(--navy)]",
        // Code
        "[&_code]:bg-black/5 [&_code]:px-1.5 [&_code]:py-0.5 [&_code]:rounded [&_code]:text-sm [&_code]:font-mono [&_code]:text-[var(--orange-dark)]",
        "[&_pre]:bg-[var(--navy-dark)] [&_pre]:text-white [&_pre]:p-4 [&_pre]:rounded-lg [&_pre]:overflow-x-auto [&_pre]:my-5 [&_pre]:text-sm",
        "[&_pre_code]:bg-transparent [&_pre code]:text-white",
        // Images
        "[&_img]:rounded-xl [&_img]:shadow-md [&_img]:my-6 [&_img]:w-full",
        // Horizontal rule
        "[&_hr]:border-none [&_hr]:h-px [&_hr]:bg-gradient-to-r [&_hr]:from-transparent [&_hr]:via-[var(--orange)]/40 [&_hr]:to-transparent [&_hr]:my-8",
        // Tables
        "[&_table]:w-full [&_table]:my-6 [&_table]:border-collapse",
        "[&_th]:border [&_th]:border-black/10 [&_th]:bg-[var(--cream)] [&_th]:px-3 [&_th]:py-2 [&_th]:text-left [&_th]:font-semibold [&_th]:text-[var(--navy)]",
        "[&_td]:border [&_td]:border-black/10 [&_td]:px-3 [&_td]:py-2",
        "[&_tr]:hover:[&_td]:bg-[var(--cream)]/30",
        className,
      )}
    >
      <ReactMarkdown
        components={{
          // Open links in new tab if external
          a: ({ node, ...props }) => {
            const href = props.href || "";
            const isExternal = href.startsWith("http");
            return (
              <a
                {...props}
                {...(isExternal ? { target: "_blank", rel: "noopener noreferrer" } : {})}
              />
            );
          },
          img: ({ node, ...props }) => (
            <img {...props} loading="lazy" alt={props.alt || ""} />
          ),
        }}
      >
        {content}
      </ReactMarkdown>
    </div>
  );
}
