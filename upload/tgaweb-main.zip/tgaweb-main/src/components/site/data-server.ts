/**
 * Public site data — read from DB via the content layer.
 * Falls back to safe defaults if DB is empty (e.g. before seed runs).
 */

import {
  getSiteSettings,
  getStats,
  getValues,
  getPrograms,
  getProgramBySlug,
  getFaculty,
  getFacultyBySlug,
  getTestimonials,
  getTestimonialBySlug,
  getPublishedNews,
  getNewsBySlug,
  getRelatedNews,
  getNewsCategories,
  getAllNews,
  getAdmissionSteps,
  getFaqs,
  getFaqBySlug,
  getRelatedFaqs,
  getCampusItems,
  getCampusItemBySlug,
  getActiveSlides,
} from "@/lib/content";

export { getSiteSettings } from "@/lib/content";
export {
  getProgramBySlug,
  getFacultyBySlug,
  getTestimonialBySlug,
  getNewsBySlug,
  getRelatedNews,
  getNewsCategories,
  getAllNews,
  getFaqBySlug,
  getRelatedFaqs,
  getCampusItemBySlug,
} from "@/lib/content";

// Type helpers (mirror Prisma models)
type Awaited<T> = T extends Promise<infer U> ? U : T;

export async function getSiteData() {
  const [
    settings,
    stats,
    values,
    programs,
    faculty,
    testimonials,
    news,
    admissionSteps,
    faqs,
    campusItems,
    slides,
  ] = await Promise.all([
    getSiteSettings(),
    getStats(),
    getValues(),
    getPrograms(),
    getFaculty(),
    getTestimonials(),
    getPublishedNews(),
    getAdmissionSteps(),
    getFaqs(),
    getCampusItems(),
    getActiveSlides(),
  ]);

  return {
    settings,
    stats,
    values,
    programs,
    faculty,
    testimonials,
    news,
    admissionSteps,
    faqs,
    campusItems,
    slides,
  };
}

// Format helper for news dates
export function formatDate(iso: string | Date) {
  const d = typeof iso === "string" ? new Date(iso) : iso;
  return d.toLocaleDateString("en-GB", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}
