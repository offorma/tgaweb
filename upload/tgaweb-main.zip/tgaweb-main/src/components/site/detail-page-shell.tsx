import { Navbar } from "@/components/site/navbar";
import { Footer } from "@/components/site/footer";
import { getSiteSettings } from "@/lib/content";
import type { SiteSettings } from "@prisma/client";
import { Link } from "@/i18n/routing";
import { ArrowLeft } from "lucide-react";
import { getTranslations } from "next-intl/server";

/**
 * Shared layout for public detail pages (news article, program, faculty, etc).
 *
 * Renders the standard Navbar + Footer with the page content sandwiched between,
 * plus a slim "back to listing" breadcrumb bar at the top.
 *
 * Usage:
 *   import { DetailPageShell } from "@/components/site/detail-page-shell";
 *
 *   export default async function NewsArticlePage({ params }) {
 *     const item = await getNewsBySlug(params.slug);
 *     if (!item) notFound();
 *     return (
 *       <DetailPageShell backHref="/news" backLabelKey="newsDetail.backToNews">
 *         <article>...</article>
 *       </DetailPageShell>
 *     );
 *   }
 */

export async function DetailPageShell({
  children,
  backHref,
  backLabelKey,
  settings,
}: {
  children: React.ReactNode;
  backHref: string;
  backLabelKey: string; // e.g. "newsDetail.backToNews"
  settings?: SiteSettings | null;
}) {
  const t = await getTranslations();
  // Resolve the back label — split on first dot
  const [namespace, key] = backLabelKey.split(".");
  let backLabel: string;
  try {
    backLabel = t(namespace, key);
  } catch {
    backLabel = "Back";
  }

  // Fetch settings if not provided
  const s = settings !== undefined ? settings : await getSiteSettings();

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar settings={s} />
      <main className="flex-1">
        {/* Slim back-link bar */}
        <div className="border-b border-black/5 bg-[var(--cream)]/40">
          <div className="max-w-5xl mx-auto px-6 py-4">
            <Link
              href={backHref}
              className="inline-flex items-center gap-1.5 text-sm font-medium text-[var(--navy)] hover:text-[var(--orange-dark)] transition-colors"
            >
              <ArrowLeft className="h-4 w-4" />
              {backLabel}
            </Link>
          </div>
        </div>

        {children}
      </main>
      <Footer settings={s} />
    </div>
  );
}
