"use client";

import { useState } from "react";
import { Link } from "@/i18n/routing";
import { motion, AnimatePresence } from "framer-motion";
import { Plus, Minus, ChevronRight } from "lucide-react";
import type { Faq } from "@prisma/client";

function FaqAccordion({ items }: { items: Faq[] }) {
  const [open, setOpen] = useState<string | null>(items[0]?.id ?? null);

  return (
    <div className="space-y-3">
      {items.map((item) => {
        const isOpen = open === item.id;
        return (
          <div
            key={item.id}
            className="bg-white rounded-2xl shadow-sm overflow-hidden border border-black/5"
          >
            <button
              onClick={() => setOpen(isOpen ? null : item.id)}
              className="w-full flex items-center justify-between gap-4 p-5 text-left"
            >
              <span className="font-serif text-lg font-bold text-[var(--navy)]">
                {item.question}
              </span>
              <div className="h-8 w-8 rounded-full bg-[var(--orange)]/10 flex items-center justify-center flex-shrink-0">
                {isOpen ? (
                  <Minus className="h-4 w-4 text-[var(--orange-dark)]" />
                ) : (
                  <Plus className="h-4 w-4 text-[var(--orange-dark)]" />
                )}
              </div>
            </button>
            <AnimatePresence initial={false}>
              {isOpen && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.25 }}
                  className="overflow-hidden"
                >
                  <div className="px-5 pb-5">
                    <p className="text-muted-foreground leading-relaxed">
                      {item.answer}
                    </p>
                    <Link
                      href={`/faq/${item.slug}`}
                      className="mt-3 inline-flex items-center gap-1 text-sm font-semibold text-[var(--orange-dark)] hover:gap-2 transition-all"
                    >
                      View full answer
                      <ChevronRight className="h-4 w-4" />
                    </Link>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        );
      })}
    </div>
  );
}

export { FaqAccordion };
