"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, ChevronLeft, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * Image gallery with lightbox. Parses newline-separated URLs into a grid.
 * Click any image to open a full-screen carousel.
 */
export function ImageGallery({
  images,
  className,
}: {
  images: string;
  className?: string;
}) {
  const urls = images
    .split("\n")
    .map((s) => s.trim())
    .filter(Boolean);

  if (urls.length === 0) return null;

  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  const close = () => setLightboxIndex(null);
  const prev = (e: React.MouseEvent) => {
    e.stopPropagation();
    setLightboxIndex((i) => (i === null ? null : (i - 1 + urls.length) % urls.length));
  };
  const next = (e: React.MouseEvent) => {
    e.stopPropagation();
    setLightboxIndex((i) => (i === null ? null : (i + 1) % urls.length));
  };

  // Choose grid columns based on count
  const gridClass =
    urls.length === 1
      ? "grid-cols-1 max-w-xl"
      : urls.length === 2
        ? "grid-cols-2"
        : urls.length === 3
          ? "grid-cols-3"
          : "grid-cols-2 md:grid-cols-3";

  return (
    <>
      <div className={cn("grid gap-3", gridClass, className)}>
        {urls.map((url, i) => (
          <motion.button
            key={i}
            type="button"
            onClick={() => setLightboxIndex(i)}
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.3, delay: i * 0.05 }}
            className={cn(
              "group relative overflow-hidden rounded-xl shadow-md hover:shadow-xl transition-shadow",
              urls.length === 1 ? "aspect-[16/10]" : "aspect-square",
            )}
          >
            <img
              src={url}
              alt={`Gallery image ${i + 1}`}
              loading="lazy"
              className="absolute inset-0 h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
            />
            <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors" />
          </motion.button>
        ))}
      </div>

      <AnimatePresence>
        {lightboxIndex !== null && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={close}
            className="fixed inset-0 z-[100] bg-black/90 backdrop-blur-sm flex items-center justify-center p-6"
          >
            <button
              onClick={close}
              aria-label="Close"
              className="absolute top-6 right-6 h-12 w-12 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors"
            >
              <X className="h-6 w-6" />
            </button>

            {urls.length > 1 && (
              <button
                onClick={prev}
                aria-label="Previous"
                className="absolute left-6 h-12 w-12 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors"
              >
                <ChevronLeft className="h-6 w-6" />
              </button>
            )}

            <motion.img
              key={lightboxIndex}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              src={urls[lightboxIndex]}
              alt={`Gallery image ${lightboxIndex + 1}`}
              className="max-w-full max-h-[85vh] object-contain rounded-lg shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            />

            {urls.length > 1 && (
              <button
                onClick={next}
                aria-label="Next"
                className="absolute right-6 h-12 w-12 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors"
              >
                <ChevronRight className="h-6 w-6" />
              </button>
            )}

            <div className="absolute bottom-6 left-1/2 -translate-x-1/2 text-white/70 text-sm">
              {lightboxIndex + 1} / {urls.length}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
