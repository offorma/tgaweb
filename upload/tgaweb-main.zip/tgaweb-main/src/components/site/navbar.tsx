"use client";

import { useState, useEffect } from "react";
import { Link, usePathname } from "@/i18n/routing";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X, Phone, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import type { SiteSettings } from "@prisma/client";
import { ApplyButton } from "./apply-button";
import { LanguageSwitcher } from "./language-switcher";
import { useTranslations } from "next-intl";

// Mix of in-page anchors (homepage sections) and real routes (listing pages).
// `anchor: true` means smooth-scroll on homepage; `anchor: false` is a real Next route.
const NAV_LINKS = [
  { key: "home", href: "/", anchor: false },
  { key: "about", href: "/#about", anchor: true },
  { key: "academics", href: "/programs", anchor: false },
  { key: "campusLife", href: "/campus-life", anchor: false },
  { key: "admissions", href: "/#admissions", anchor: true },
  { key: "news", href: "/news", anchor: false },
  { key: "contact", href: "/#contact", anchor: true },
] as const;

export function Navbar({ settings }: { settings: SiteSettings | null }) {
  const t = useTranslations("nav");
  const pathname = usePathname();
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [activeSection, setActiveSection] = useState("home");

  const crest = settings?.crestUrl || "/crest/school-crest.png";
  const phone = settings?.phone || "";
  const hours = settings?.hours || "";
  const isHome = pathname === "/";

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 40);
      // Only track active section on the homepage
      if (!isHome) return;
      const sections = ["home", "about", "admissions", "contact"];
      for (const s of sections) {
        const el = document.getElementById(s);
        if (el) {
          const rect = el.getBoundingClientRect();
          if (rect.top <= 120 && rect.bottom >= 120) {
            setActiveSection(s);
            break;
          }
        }
      }
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener("scroll", onScroll);
  }, [isHome]);

  const handleNav = (href: string, anchor: boolean) => {
    setOpen(false);
    if (anchor && isHome) {
      const id = href.split("#")[1];
      const el = document.getElementById(id);
      if (el) {
        el.scrollIntoView({ behavior: "smooth", block: "start" });
      }
    }
    // For non-anchor links or non-home pages, let Next.js handle the navigation
  };

  const isLinkActive = (link: (typeof NAV_LINKS)[number]) => {
    if (link.anchor) {
      return isHome && activeSection === link.href.split("#")[1];
    }
    // Real routes: highlight if pathname starts with the route
    if (link.href === "/") return pathname === "/";
    return pathname === link.href || pathname.startsWith(link.href + "/");
  };

  return (
    <>
      <div className="hidden md:block bg-[var(--navy)] text-white/90 text-xs">
        <div className="max-w-7xl mx-auto px-6 h-9 flex items-center justify-between">
          <div className="flex items-center gap-6">
            <span className="flex items-center gap-1.5">
              <Phone className="h-3 w-3 text-[var(--orange)]" />
              {phone}
            </span>
            <span className="text-white/40">|</span>
            <span className="text-white/80">{hours}</span>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-white/60 hidden sm:inline">{t("followJourney")}</span>
            <div className="flex items-center gap-2">
              {[
                { label: "Facebook", url: settings?.facebookUrl },
                { label: "Instagram", url: settings?.instagramUrl },
                { label: "YouTube", url: settings?.youtubeUrl },
              ].filter((s) => s.url).map((s) => (
                <a
                  key={s.label}
                  href={s.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-[var(--orange)] transition-colors"
                  aria-label={s.label}
                >
                  {s.label}
                </a>
              ))}
            </div>
            <span className="text-white/20 hidden sm:inline">|</span>
            <LanguageSwitcher className="text-white/90" />
          </div>
        </div>
      </div>

      <motion.header
        initial={{ y: -10, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5 }}
        className={cn(
          "sticky top-0 z-50 transition-all duration-300",
          scrolled || !isHome
            ? "bg-white/90 backdrop-blur-xl shadow-md border-b border-black/5"
            : "bg-transparent"
        )}
      >
        <nav className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between gap-4">
          <Link
            href="/"
            className="flex items-center gap-3 group"
          >
            <div className="relative h-12 w-12 rounded-full overflow-hidden ring-2 ring-[var(--orange)]/40 group-hover:ring-[var(--orange)] transition-all">
              <img
                src={crest}
                alt="Trail Gliders Academy Crest"
                className="h-full w-full object-cover"
              />
            </div>
            <div className="text-left leading-tight">
              <div
                className={cn(
                  "font-serif font-bold text-lg transition-colors",
                  scrolled || !isHome ? "text-[var(--navy)]" : "text-[var(--navy)]"
                )}
              >
                Trail Gliders
              </div>
              <div className="text-[10px] uppercase tracking-[0.2em] text-[var(--orange)] font-semibold">
                Academy • Nsukka
              </div>
            </div>
          </Link>

          <div className="hidden lg:flex items-center gap-1">
            {NAV_LINKS.map((link) => {
              const isActive = isLinkActive(link);
              // For anchor links on non-home pages, we still want Next.js to navigate to /#anchor
              if (link.anchor && !isHome) {
                return (
                  <Link
                    key={link.href}
                    href={link.href}
                    className={cn(
                      "relative px-4 py-2 text-sm font-medium transition-colors rounded-md",
                      isActive
                        ? "text-[var(--orange)]"
                        : "text-[var(--navy)] hover:text-[var(--orange)]"
                    )}
                  >
                    {t(link.key)}
                  </Link>
                );
              }
              // For real routes or in-page anchors
              const Tag = link.anchor ? "button" : Link;
              const props: any = link.anchor
                ? { onClick: () => handleNav(link.href, true) }
                : { href: link.href };
              return (
                <Tag
                  key={link.href}
                  {...props}
                  className={cn(
                    "relative px-4 py-2 text-sm font-medium transition-colors rounded-md",
                    isActive
                      ? "text-[var(--orange)]"
                      : "text-[var(--navy)] hover:text-[var(--orange)]"
                  )}
                >
                  {t(link.key)}
                  {isActive && (
                    <motion.span
                      layoutId="nav-underline"
                      className="absolute left-3 right-3 -bottom-0.5 h-0.5 rounded-full bg-gradient-to-r from-[var(--orange)] to-[var(--gold)]"
                    />
                  )}
                </Tag>
              );
            })}
          </div>

          <div className="hidden lg:block">
            <ApplyButton
              settings={settings}
              size="default"
              className="shadow-lg shadow-orange-500/25 hover:shadow-orange-500/40 transition-all"
            >
              <Calendar className="h-4 w-4 mr-1.5" />
              {settings?.applyButtonLabel || t("applyNow")}
            </ApplyButton>
          </div>

          <button
            className="lg:hidden p-2 rounded-md text-[var(--navy)]"
            onClick={() => setOpen(!open)}
            aria-label="Toggle menu"
          >
            {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </nav>

        <AnimatePresence>
          {open && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.25 }}
              className="lg:hidden overflow-hidden bg-white border-t border-black/5"
            >
              <div className="px-6 py-4 flex flex-col gap-1">
                {NAV_LINKS.map((link) =>
                  link.anchor && !isHome ? (
                    <Link
                      key={link.href}
                      href={link.href}
                      onClick={() => setOpen(false)}
                      className="text-left px-3 py-3 text-base font-medium text-[var(--navy)] hover:bg-[var(--cream)] hover:text-[var(--orange)] rounded-md transition-colors"
                    >
                      {t(link.key)}
                    </Link>
                  ) : link.anchor ? (
                    <button
                      key={link.href}
                      onClick={() => handleNav(link.href, true)}
                      className="text-left px-3 py-3 text-base font-medium text-[var(--navy)] hover:bg-[var(--cream)] hover:text-[var(--orange)] rounded-md transition-colors"
                    >
                      {t(link.key)}
                    </button>
                  ) : (
                    <Link
                      key={link.href}
                      href={link.href}
                      onClick={() => setOpen(false)}
                      className="text-left px-3 py-3 text-base font-medium text-[var(--navy)] hover:bg-[var(--cream)] hover:text-[var(--orange)] rounded-md transition-colors"
                    >
                      {t(link.key)}
                    </Link>
                  ),
                )}
                <div className="mt-2">
                  <ApplyButton
                    settings={settings}
                    size="default"
                    className="w-full"
                  >
                    <Calendar className="h-4 w-4 mr-1.5" />
                    {settings?.applyButtonLabel || t("applyNow")}
                  </ApplyButton>
                </div>
                <div className="mt-2 px-3">
                  <LanguageSwitcher className="text-[var(--navy)]" />
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.header>
    </>
  );
}
