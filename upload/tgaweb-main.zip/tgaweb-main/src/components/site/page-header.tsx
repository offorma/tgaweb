import { motion } from "framer-motion";

/**
 * Standard hero header for listing/archive pages.
 * Badge + title + optional description.
 */
export function PageHeader({
  badge,
  title1,
  title2,
  description,
}: {
  badge?: string;
  title1: string;
  title2?: string;
  description?: string;
}) {
  return (
    <section className="pt-32 pb-12 lg:pt-40 lg:pb-16 bg-mesh-cream relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="max-w-3xl"
        >
          {badge && (
            <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[var(--navy)]/10 text-[var(--navy)] text-xs font-bold uppercase tracking-[0.18em]">
              <span className="h-1.5 w-1.5 rounded-full bg-[var(--navy)]" />
              {badge}
            </span>
          )}
          <h1 className="mt-5 font-serif font-bold text-4xl sm:text-5xl lg:text-6xl text-[var(--navy)] leading-[1.1] text-balance">
            {title1}
            {title2 && <span className="gradient-text-orange"> {title2}</span>}
          </h1>
          {description && (
            <p className="mt-5 text-lg text-muted-foreground leading-relaxed">
              {description}
            </p>
          )}
        </motion.div>
      </div>
    </section>
  );
}
