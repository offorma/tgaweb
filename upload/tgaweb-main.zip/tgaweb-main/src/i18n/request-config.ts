import { getRequestConfig } from 'next-intl/server';
import { routing } from './routing';

/**
 * Request-scoped i18n config — picks the locale from the URL (via routing)
 * and loads the corresponding messages file.
 *
 * With `localePrefix: 'always'`, the locale is part of the URL (e.g. /fr/news).
 * next-intl automatically extracts it; we just load the messages file.
 */
export default getRequestConfig(async ({ requestLocale }) => {
  // `requestLocale` is the locale detected by next-intl's middleware from the URL prefix
  let locale = await requestLocale;

  // Fallback to default if the URL didn't have a locale prefix
  if (!locale || !routing.locales.includes(locale as any)) {
    locale = routing.defaultLocale;
  }

  return {
    locale,
    messages: (await import(`../../messages/${locale}.json`)).default,
  };
});
