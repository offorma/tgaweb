import { defineRouting } from 'next-intl/routing';
import { createNavigation } from 'next-intl/navigation';

/**
 * next-intl routing configuration.
 *
 * `localePrefix: 'always'` means every public URL is prefixed with the locale:
 *   /en/news/my-article
 *   /fr/news/my-article
 *   /ha/news/my-article
 *   /ig/news/my-article
 *   /yo/news/my-article
 *
 * The root path `/` redirects to `/en/` (defaultLocale) on first visit, or to
 * the user's preferred locale if Accept-Language matches.
 */
export const routing = defineRouting({
  locales: ['en', 'fr', 'ha', 'ig', 'yo'],
  defaultLocale: 'en',
  localePrefix: 'always',
});

/**
 * Locale-aware navigation utilities.
 *
 * Use these INSTEAD of `next/link` and `next/navigation` in public components:
 *   - `Link` from `next-intl/navigation` auto-adds the locale prefix to hrefs
 *   - `usePathname` returns the pathname WITHOUT the locale prefix (so `isHome` = `pathname === "/"`)
 *   - `useRouter` for programmatic navigation with locale awareness
 *
 * Admin components should continue using `next/link` and `next/navigation`
 * (admin routes are not localized).
 */
export const { Link, redirect, usePathname, useRouter, getPathname } = createNavigation(routing);

export type { Locale } from 'next-intl/routing';
