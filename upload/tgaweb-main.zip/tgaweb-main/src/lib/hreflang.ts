import type { Metadata } from "next";
import { routing } from "@/i18n/routing";

/**
 * Generate hreflang alternate URLs for SEO.
 *
 * Returns an object mapping locale codes to URL paths.
 * Next.js will render these as <link rel="alternate" hreflang="..." href="..."> tags.
 *
 * Usage in generateMetadata():
 *   export async function generateMetadata({ params }): Promise<Metadata> {
 *     const { locale, slug } = await params;
 *     return {
 *       title: "...",
 *       alternates: {
 *         languages: hreflangAlternates(`/news/${slug}`),
 *       },
 *     };
 *   }
 */
export function hreflangAlternates(
  pathname: string,
): Record<string, string> {
  const result: Record<string, string> = {};
  for (const locale of routing.locales) {
    // Each locale gets its own URL: /en/news/article, /fr/news/article, etc.
    result[locale] = `/${locale}${pathname}`;
  }
  // Also add x-default pointing to the English version
  result["x-default"] = `/en${pathname}`;
  return result;
}

/**
 * Generate locale-aware metadata for a detail page.
 * Includes title, description, openGraph, and hreflang alternates.
 */
export function localeMetadata({
  title,
  description,
  pathname,
  image,
  locale,
}: {
  title: string;
  description: string;
  pathname: string;
  image?: string;
  locale: string;
}): Metadata {
  // Map our locale codes to OpenGraph locale codes
  const ogLocaleMap: Record<string, string> = {
    en: "en_NG",
    fr: "fr_FR",
    ha: "ha_NG",
    ig: "ig_NG",
    yo: "yo_NG",
  };

  return {
    title,
    description,
    alternates: {
      languages: hreflangAlternates(pathname),
    },
    openGraph: {
      title,
      description,
      locale: ogLocaleMap[locale] || "en_NG",
      images: image ? [{ url: image }] : undefined,
      type: "article",
    },
    twitter: {
      card: "summary_large_image",
      title,
      description,
      images: image ? [image] : undefined,
    },
  };
}
