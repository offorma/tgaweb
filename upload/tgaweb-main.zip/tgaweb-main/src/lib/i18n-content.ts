/**
 * i18n content helper — resolves translatable DB fields to the visitor's locale.
 *
 * The DB stores content fields in two forms:
 *   1. The original `String` field (English source of truth, e.g. `newsItem.title`)
 *   2. An optional `Json?` field with translations (e.g. `newsItem.titleI18n`)
 *      Structure: `{ en: "...", fr: "...", ha: "...", ig: "...", yo: "..." }`
 *
 * Resolution rule (per user choice "Fall back to English"):
 *   - If the i18n field exists and has a non-empty value for the current locale → use it
 *   - Else → fall back to the English `String` field
 *
 * Usage in server components:
 *   import { getLocale } from 'next-intl/server';
 *   import { t } from '@/lib/i18n-content';
 *   const locale = await getLocale();
 *   <h1>{t(newsItem.titleI18n, newsItem.title, locale)}</h1>
 *
 * Usage in client components (pass locale as prop):
 *   <News news={news} locale={locale} />
 *   → inside: t(item.titleI18n, item.title, locale)
 */

export type Locale = 'en' | 'fr' | 'ha' | 'ig' | 'yo';

export const LOCALES: Locale[] = ['en', 'fr', 'ha', 'ig', 'yo'];

export const LOCALE_LABELS: Record<Locale, { name: string; native: string; flag: string }> = {
  en: { name: 'English', native: 'English', flag: '🇬🇧' },
  fr: { name: 'French', native: 'Français', flag: '🇫🇷' },
  ha: { name: 'Hausa', native: 'Hausa', flag: '🇳🇬' },
  ig: { name: 'Igbo', native: 'Igbo', flag: '🇳🇬' },
  yo: { name: 'Yoruba', native: 'Yorùbá', flag: '🇳🇬' },
};

/**
 * A translation JSON object — keys are locale codes, values are translated strings.
 * Example: `{ en: "Hello", fr: "Bonjour", ha: "Sannu", ig: "Ndewo", yo: "Pẹlẹ" }`
 */
export type I18nField = Record<string, string> | null | undefined;

/**
 * Resolve a translatable field to the visitor's locale, falling back to English.
 *
 * @param i18nField  The JSON translation object (e.g. `item.titleI18n`)
 * @param fallback   The English source-of-truth string (e.g. `item.title`)
 * @param locale     The visitor's locale code (e.g. 'fr')
 * @returns          The translated string, or the English fallback if missing
 */
export function t(
  i18nField: I18nField,
  fallback: string,
  locale: string | undefined,
): string {
  if (!locale || locale === 'en') return fallback;
  const translated = i18nField?.[locale];
  if (translated && translated.trim()) return translated;
  return fallback;
}

/**
 * Same as `t()` but for multi-line text fields (e.g. markdown body).
 * Identical behavior — included for semantic clarity at call sites.
 */
export function tBody(
  i18nField: I18nField,
  fallback: string,
  locale: string | undefined,
): string {
  return t(i18nField, fallback, locale);
}

/**
 * Check if a translation exists for a given locale (without falling back).
 * Useful for showing "translation available" indicators in admin UI.
 */
export function hasTranslation(
  i18nField: I18nField,
  locale: string,
): boolean {
  if (locale === 'en') return true; // English is always present (the source field)
  return Boolean(i18nField?.[locale]?.trim());
}

/**
 * Initialize an empty i18n object for a new record.
 * Returns `{ en: "", fr: "", ha: "", ig: "", yo: "" }`.
 */
export function emptyI18n(): Record<Locale, string> {
  return { en: '', fr: '', ha: '', ig: '', yo: '' };
}

/**
 * Validate that a value is a well-formed i18n object.
 * Used by API routes to reject malformed input.
 */
export function isI18nObject(value: unknown): value is Record<string, string> {
  if (!value || typeof value !== 'object') return false;
  const obj = value as Record<string, unknown>;
  // Allow any subset of locale keys, all values must be strings
  for (const key of Object.keys(obj)) {
    if (!LOCALES.includes(key as Locale)) continue; // ignore unknown keys
    if (typeof obj[key] !== 'string') return false;
  }
  return true;
}
