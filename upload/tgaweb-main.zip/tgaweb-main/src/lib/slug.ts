/**
 * Slug utilities — convert titles to URL-safe slugs and ensure uniqueness.
 *
 * Usage:
 *   import { slugify, ensureUniqueSlug } from "@/lib/slug";
 *
 *   const base = slugify("New Science Lab Opens!");
 *   // → "new-science-lab-opens"
 *
 *   const unique = await ensureUniqueSlug(base, async (slug) => {
 *     return await db.newsItem.findUnique({ where: { slug } });
 *   });
 *   // → "new-science-lab-opens" or "new-science-lab-opens-2" if taken
 */

/**
 * Convert any string to a URL-safe slug.
 * - Lowercase
 * - Replace spaces/underscores with hyphens
 * - Strip non-alphanumeric (except hyphens)
 * - Collapse multiple hyphens
 * - Trim leading/trailing hyphens
 * - Fallback to "untitled" if result is empty
 */
export function slugify(input: string): string {
  return (
    input
      .toString()
      .normalize("NFKD") // decompose accented chars (é → e)
      .replace(/[\u0300-\u036f]/g, "") // strip diacritics
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9\s-]/g, "") // remove non-alphanumeric (keep spaces, hyphens)
      .replace(/[\s_]+/g, "-") // spaces/underscores → hyphen
      .replace(/-+/g, "-") // collapse multiple hyphens
      .replace(/^-+|-+$/g, "") // trim leading/trailing hyphens
      .slice(0, 80) // cap length
    || "untitled"
  );
}

/**
 * Ensure a slug is unique by appending -2, -3, ... if it already exists.
 *
 * @param baseSlug  The desired slug (already slugified)
 * @param exists    Async function that returns truthy if the slug is taken
 * @param excludeId Optional record id to exclude from the check (for updates)
 *
 * @returns A unique slug
 *
 * @example
 *   const slug = await ensureUniqueSlug(
 *     slugify("New Lab"),
 *     (slug) => db.newsItem.findUnique({ where: { slug } }),
 *     existingId,
 *   );
 */
export async function ensureUniqueSlug(
  baseSlug: string,
  exists: (slug: string) => Promise<unknown>,
  excludeId?: string,
): Promise<string> {
  // First try the base slug
  const existing = await exists(baseSlug);
  if (!existing || (excludeId && (existing as { id?: string }).id === excludeId)) {
    return baseSlug;
  }

  // Append -2, -3, ... until unique
  for (let i = 2; i < 1000; i++) {
    const candidate = `${baseSlug}-${i}`;
    const conflict = await exists(candidate);
    if (!conflict || (excludeId && (conflict as { id?: string }).id === excludeId)) {
      return candidate;
    }
  }

  // Fallback: append a random suffix (extremely unlikely to hit this)
  return `${baseSlug}-${Math.random().toString(36).slice(2, 8)}`;
}

/**
 * Validate that a string is a valid slug.
 * Used by API routes to reject malformed input.
 */
export function isValidSlug(slug: string): boolean {
  return /^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(slug) && slug.length <= 80;
}
